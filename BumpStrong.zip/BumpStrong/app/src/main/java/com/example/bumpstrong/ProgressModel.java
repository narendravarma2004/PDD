package com.example.bumpstrong;

public class ProgressModel {
    private int id;
    private String patientId;
    private String taskDate;
    private int completed;

    public ProgressModel(int id, String patientId, String taskDate, int completed) {
        this.id = id;
        this.patientId = patientId;
        this.taskDate = taskDate;
        this.completed = completed;
    }

    public int getId() {
        return id;
    }

    public String getPatientId() {
        return patientId;
    }

    public String getTaskDate() {
        return taskDate;
    }

    public boolean isCompleted() {
        return completed == 1;
    }
}
