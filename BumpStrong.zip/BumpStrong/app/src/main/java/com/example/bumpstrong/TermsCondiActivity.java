package com.example.bumpstrong;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.bumpstrong.PatientLoginActivity;

public class TermsCondiActivity extends AppCompatActivity {

    private CheckBox chkDeclaration, chkAffirmation;
    private Button btnSignUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_termscondi); // ✅ Corrected layout file

        // Initialize checkboxes and button
        chkDeclaration = findViewById(R.id.chkDeclaration);
        chkAffirmation = findViewById(R.id.chkAffirmation);
        btnSignUp = findViewById(R.id.btnSignUp);

        // Check if button is null before setting listener
        if (btnSignUp == null) {
            Toast.makeText(this, "Button not found! Check layout file.", Toast.LENGTH_LONG).show();
            return;
        }
        // Set click listener for sign-up button
        btnSignUp.setOnClickListener(v -> {
            if (chkDeclaration.isChecked() && chkAffirmation.isChecked()) {
                // Proceed to the next screen
                Intent intent = new Intent(TermsCondiActivity.this, PatientSignUpActivity.class);
                startActivity(intent);
            } else {
                // Show error if checkboxes are not checked
                Toast.makeText(TermsCondiActivity.this, "Please accept the terms and conditions", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
