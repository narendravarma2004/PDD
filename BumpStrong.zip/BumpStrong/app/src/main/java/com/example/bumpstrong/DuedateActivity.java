package com.example.bumpstrong;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class DuedateActivity extends AppCompatActivity {

    private EditText etLastPeriod, etDueDate;
    private Button btnOk;
    private Calendar calendar = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_due_date);

        etLastPeriod = findViewById(R.id.etLastPeriod);
        etDueDate = findViewById(R.id.etDueDate);
        btnOk = findViewById(R.id.btnOk);

        // Open Date Picker when clicking on Last Period field
        etLastPeriod.setOnClickListener(v -> showDatePicker());

        btnOk.setOnClickListener(v -> {
            Intent intent = new Intent(DuedateActivity.this, QuestionariesActivity.class);
            startActivity(intent);
        });
    }

    private void showDatePicker() {
        Calendar newCalendar = Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this, (view, year, month, dayOfMonth) -> {
            calendar.set(year, month, dayOfMonth);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            etLastPeriod.setText(sdf.format(calendar.getTime()));

            // Calculate due date (280 days from last period)
            Calendar dueDateCal = (Calendar) calendar.clone();
            dueDateCal.add(Calendar.DAY_OF_YEAR, 280);
            etDueDate.setText(sdf.format(dueDateCal.getTime()));

            // Calculate pregnancy weeks
            int weeksPregnant = calculatePregnancyWeeks();
            showPregnancyPopup(weeksPregnant);
        },
                newCalendar.get(Calendar.YEAR),
                newCalendar.get(Calendar.MONTH),
                newCalendar.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.show();
    }

    private int calculatePregnancyWeeks() {
        if (etLastPeriod.getText().toString().isEmpty()) return 0;

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        Calendar today = Calendar.getInstance();
        Calendar lastPeriodDate = Calendar.getInstance();

        try {
            lastPeriodDate.setTime(sdf.parse(etLastPeriod.getText().toString()));
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }

        long diffInMillis = today.getTimeInMillis() - lastPeriodDate.getTimeInMillis();
        return (int) (diffInMillis / (1000L * 60 * 60 * 24 * 7)); // Convert milliseconds to weeks
    }

    private void showPregnancyPopup(int weeksPregnant) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Pregnancy Status")
                .setMessage("Congratulations! You are " + weeksPregnant + " weeks pregnant.")
                .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                .show();
    }
}
