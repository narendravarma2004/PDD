package com.example.bumpstrong;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.squareup.picasso.Picasso;
import java.util.List;

public class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.VideoViewHolder> {
    private Context context;
    private List<VideoItem> videoList; // <-- Fixed import issue

    private static final String TAG = "VideoAdapter";

    public VideoAdapter(Context context, List<VideoItem> videoList) {
        this.context = context;
        this.videoList = videoList;
    }

    @NonNull
    @Override
    public VideoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.video_item1, parent, false);
        return new VideoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VideoViewHolder holder, int position) {
        VideoItem video = videoList.get(position);
        holder.title.setText(video.getTitle());

        String thumbnailUrl = video.getThumbnailUrl();
        Log.d(TAG, "Position: " + position + ", Title: " + video.getTitle() + ", Thumbnail URL: " + thumbnailUrl);

        holder.thumbnail.setImageDrawable(null);

        if (thumbnailUrl != null && !thumbnailUrl.isEmpty()) {
            Picasso.get()
                    .load(thumbnailUrl)
                    .noPlaceholder()
                    .error(R.drawable.error_image)
                    .into(holder.thumbnail);
        } else {
            holder.thumbnail.setImageResource(R.drawable.default_image);
            Log.w(TAG, "Thumbnail URL is null or empty for: " + video.getTitle());
        }

        holder.title.setOnClickListener(v -> {
            String videoUrl = video.getVideoUrl();
            Log.d(TAG, "Clicked video: " + video.getTitle() + ", URL: " + videoUrl);

            if (videoUrl == null || videoUrl.isEmpty()) {
                Toast.makeText(context, "Video URL is invalid", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                Uri videoUri = Uri.parse(videoUrl);
                intent.setDataAndType(videoUri, "video/*");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                if (intent.resolveActivity(context.getPackageManager()) != null) {
                    context.startActivity(intent);
                } else {
                    Toast.makeText(context, "No video player app installed", Toast.LENGTH_LONG).show();
                    Log.e(TAG, "No activity to handle video intent");
                }
            } catch (Exception e) {
                Log.e(TAG, "Error launching video: " + e.getMessage());
                Toast.makeText(context, "Cannot play video: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return videoList != null ? videoList.size() : 0;
    }

    public static class VideoViewHolder extends RecyclerView.ViewHolder {
        ImageView thumbnail;
        TextView title;

        public VideoViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.video_title);
            thumbnail = itemView.findViewById(R.id.thumbnail);
        }
    }
}
