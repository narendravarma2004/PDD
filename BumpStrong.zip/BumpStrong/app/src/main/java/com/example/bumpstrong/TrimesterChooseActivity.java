package com.example.bumpstrong;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;

public class TrimesterChooseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trimesterchoose);

        // Finding buttons by ID
        Button trimester1 = findViewById(R.id.btn_trimester1);
        Button trimester2 = findViewById(R.id.btn_trimester2);
        Button trimester3 = findViewById(R.id.btn_trimester3);

        // Setting click listeners for navigation
        trimester1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TrimesterChooseActivity.this, Trimester1Activity.class));
            }
        });

        trimester2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TrimesterChooseActivity.this, Trimester2Activity.class));
            }
        });

        trimester3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TrimesterChooseActivity.this, Trimester3Activity.class));
            }
        });
    }
}
