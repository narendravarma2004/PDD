package com.example.bumpstrong;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DoctorHomeActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "LoginPrefs";
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";

    private TextView welcomeText;
    private View btnPatients, btnDueDates, btnTasks, btnReports, btnKickCount, btnNotifications, btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean isLoggedIn = prefs.getBoolean(KEY_IS_LOGGED_IN, false);

        if (!isLoggedIn) {
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            return;
        }

        setContentView(R.layout.activity_doctor_home);

        welcomeText = findViewById(R.id.welcomeText);
        btnPatients = findViewById(R.id.btnPatients);
        btnDueDates = findViewById(R.id.btnDueDates);
        btnTasks = findViewById(R.id.btnTasks);
        btnReports = findViewById(R.id.btnReports);
        btnKickCount = findViewById(R.id.btnKickCount);
        btnNotifications = findViewById(R.id.btnNotifications);
        btnLogout = findViewById(R.id.btnLogout);

        btnPatients.setOnClickListener(v -> openActivity(DPatientListActivity.class));
        btnDueDates.setOnClickListener(v -> openActivity(DPatientDueDatesActivity.class));
        btnTasks.setOnClickListener(v -> openActivity(DTaskActivity.class));
        btnReports.setOnClickListener(v -> openActivity(DReportActivity.class));
        btnKickCount.setOnClickListener(v -> openActivity(DKickCountActivity.class));
        btnNotifications.setOnClickListener(v -> openActivity(DNotificationActivity.class));

        btnLogout.setOnClickListener(v -> {
            prefs.edit().putBoolean(KEY_IS_LOGGED_IN, false).apply();
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void openActivity(Class<?> activityClass) {
        startActivity(new Intent(this, activityClass));
    }

    @Override
    public void onBackPressed() {
        finishAffinity(); // closes app
    }
}
