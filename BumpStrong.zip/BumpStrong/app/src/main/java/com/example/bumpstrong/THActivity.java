package com.example.bumpstrong;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class THActivity extends AppCompatActivity {

    private RadioButton yesOption, noOption;
    private Button btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_th);

        yesOption = findViewById(R.id.radio_yes);
        noOption = findViewById(R.id.radio_no);
        btnRegister = findViewById(R.id.btn_register);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (yesOption.isChecked() || noOption.isChecked()) {
                    Toast.makeText(THActivity.this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                    // Navigate to next activity (Modify if needed)
                    Intent intent = new Intent(THActivity.this, TermsCondiActivity.class);
                    startActivity(intent);
                    finish(); // Optional: Close this activity
                } else {
                    Toast.makeText(THActivity.this, "Please select an option", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
