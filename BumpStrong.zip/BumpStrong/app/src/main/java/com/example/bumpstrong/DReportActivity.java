package com.example.bumpstrong;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textview.MaterialTextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class DReportActivity extends AppCompatActivity {
    private static final String TAG = "DReportActivity";
    private static final String FETCH_PATIENTS_URL = "http://192.168.85.64/bumpstrong/fetch_patients_with_reports.php";
    private RecyclerView rvPatients;
    private PatientAdapter patientAdapter;
    private List<Patient> patientList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_report);

        rvPatients = findViewById(R.id.rvPatients);
        MaterialButton btnBack = findViewById(R.id.btnBack);

        patientList = new ArrayList<>();
        patientAdapter = new PatientAdapter(patientList);
        rvPatients.setLayoutManager(new LinearLayoutManager(this));
        rvPatients.setAdapter(patientAdapter);

        fetchPatientsWithReports();

        btnBack.setOnClickListener(v -> finish());
    }

    private void fetchPatientsWithReports() {
        new Thread(() -> {
            try {
                URL url = new URL(FETCH_PATIENTS_URL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                int responseCode = conn.getResponseCode();
                if (responseCode != HttpURLConnection.HTTP_OK) {
                    throw new Exception("Server returned response code: " + responseCode);
                }

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder result = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }
                reader.close();

                Log.d(TAG, "Response from server: " + result.toString());
                JSONArray jsonArray = new JSONArray(result.toString());

                patientList.clear();
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject patient = jsonArray.getJSONObject(i);
                    patientList.add(new Patient(
                            patient.getString("patient_id"),
                            patient.getString("patient_name")
                    ));
                }

                runOnUiThread(() -> patientAdapter.notifyDataSetChanged());
            } catch (Exception e) {
                Log.e(TAG, "Error fetching patients: " + e.getMessage());
                runOnUiThread(() -> Toast.makeText(this, "Error fetching patients: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    // Patient data class
    private static class Patient {
        String patientId;
        String patientName;

        Patient(String patientId, String patientName) {
            this.patientId = patientId;
            this.patientName = patientName;
        }
    }

    // RecyclerView Adapter
    private class PatientAdapter extends RecyclerView.Adapter<PatientAdapter.PatientViewHolder> {
        private final List<Patient> patients;

        PatientAdapter(List<Patient> patients) {
            this.patients = patients;
        }

        @Override
        public PatientViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(android.R.layout.simple_list_item_2, parent, false);
            return new PatientViewHolder(view);
        }

        @Override
        public void onBindViewHolder(PatientViewHolder holder, int position) {
            Patient patient = patients.get(position);
            holder.text1.setText("Name: " + patient.patientName);
            holder.text2.setText("ID: " + patient.patientId);
            holder.itemView.setOnClickListener(v -> {
                Intent intent = new Intent(DReportActivity.this, DReportDetailsActivity.class);
                intent.putExtra("patient_id", patient.patientId);
                intent.putExtra("patient_name", patient.patientName);
                startActivity(intent);
            });
        }

        @Override
        public int getItemCount() {
            return patients.size();
        }

        class PatientViewHolder extends RecyclerView.ViewHolder {
            MaterialTextView text1, text2;

            PatientViewHolder(View itemView) {
                super(itemView);
                text1 = itemView.findViewById(android.R.id.text1);
                text2 = itemView.findViewById(android.R.id.text2);
            }
        }
    }
}