package com.example.bumpstrong;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class DNotificationActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private NotificationAdapter adapter;
    private List<NotificationItem> notifications;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_notification);

        recyclerView = findViewById(R.id.rvNotifications);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Create default notifications locally
        notifications = new ArrayList<>();
        notifications.add(new NotificationItem("Appointment Reminder", "You have an appointment at 3 PM", "2025-06-03 12:30"));
        notifications.add(new NotificationItem("New Message", "You received a message from a patient", "2025-06-02 10:00"));
        notifications.add(new NotificationItem("Update", "Your profile has been updated successfully", "2025-06-01 15:45"));
        notifications.add(new NotificationItem("Alert", "New COVID-19 guidelines released", "2025-05-31 09:20"));

        // Setup adapter
        adapter = new NotificationAdapter(notifications);
        recyclerView.setAdapter(adapter);

        Toast.makeText(this, "Showing default notifications", Toast.LENGTH_SHORT).show();
    }
}
