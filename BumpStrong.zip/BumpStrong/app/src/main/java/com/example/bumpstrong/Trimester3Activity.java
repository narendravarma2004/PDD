package com.example.bumpstrong;

import android.os.Bundle;
import com.example.bumpstrong.VideoData;

import android.util.Log;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Trimester3Activity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private VideoListAdapter adapter;
    private List<VideoData> videoList;
    private static final String API_URL = "http://192.168.85.64/bumpstrong/fetch_videos_trimester.php?trimester=3rd Trimester";

    private OkHttpClient client = new OkHttpClient();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trimester3);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        videoList = new ArrayList<>();
        adapter = new VideoListAdapter(this, videoList);
        recyclerView.setAdapter(adapter);

        fetchVideos();
    }

    private void fetchVideos() {
        Request request = new Request.Builder()
                .url(API_URL)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> Toast.makeText(Trimester3Activity.this, "Failed to load videos", Toast.LENGTH_SHORT).show());
                Log.e("OkHttp", "Error: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    runOnUiThread(() -> Toast.makeText(Trimester3Activity.this, "Error fetching data", Toast.LENGTH_SHORT).show());
                    return;
                }

                try {
                    JSONArray jsonArray = new JSONArray(response.body().string());
                    videoList.clear();

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);
                        String name = obj.getString("video_name");
                        String videoUrl = obj.getString("video_path");
                        String thumbnailUrl = obj.getString("thumbnail_path");

                        videoList.add(new VideoData(name, videoUrl, thumbnailUrl));
                    }

                    runOnUiThread(() -> adapter.notifyDataSetChanged());
                } catch (JSONException e) {
                    runOnUiThread(() -> Toast.makeText(Trimester3Activity.this, "Error parsing data", Toast.LENGTH_SHORT).show());
                    e.printStackTrace();
                }
            }
        });
    }
}
