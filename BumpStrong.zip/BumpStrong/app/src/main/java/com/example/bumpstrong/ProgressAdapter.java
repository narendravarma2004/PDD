package com.example.bumpstrong;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.BaseAdapter;
import java.util.List;

public class ProgressAdapter extends BaseAdapter {
    private Context context;
    private List<ProgressModel> progressList;

    public ProgressAdapter(Context context, List<ProgressModel> progressList) {
        this.context = context;
        this.progressList = progressList;
    }

    @Override
    public int getCount() {
        return progressList.size();
    }

    @Override
    public Object getItem(int position) {
        return progressList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);
        }

        TextView textPatientId = convertView.findViewById(R.id.textPatientId);
        TextView textTaskDate = convertView.findViewById(R.id.textTaskDate);
        TextView textCompleted = convertView.findViewById(R.id.textCompleted);

        ProgressModel progress = progressList.get(position);

        textPatientId.setText("Patient ID: " + progress.getPatientId());
        textTaskDate.setText("Task Date: " + progress.getTaskDate());
        textCompleted.setText(progress.isCompleted() ? "Completed" : "Pending");

        return convertView;
    }
}
