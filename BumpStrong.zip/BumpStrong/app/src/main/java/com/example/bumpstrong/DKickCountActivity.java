package com.example.bumpstrong;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class DKickCountActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private KickCountAdapter kickCountAdapter;  // This now works because adapter is defined below
    private List<PatientKickCount> patientKickCounts;
    private static final String TAG = "DKickCountActivity";
    private static final String FETCH_URL = "http://192.168.85.64/bumpstrong/fetch_kick_counts.php";

    // RecyclerView Adapter (moved up)
    private static class KickCountAdapter extends RecyclerView.Adapter<KickCountAdapter.ViewHolder> {
        private final List<PatientKickCount> patientKickCounts;

        KickCountAdapter(List<PatientKickCount> patientKickCounts) {
            this.patientKickCounts = patientKickCounts;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_kick_count, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            PatientKickCount patientKickCount = patientKickCounts.get(position);
            holder.tvPatientName.setText(patientKickCount.name);
            holder.tvKickCount.setText("Kicks: " + patientKickCount.kickCount);
        }

        @Override
        public int getItemCount() {
            return patientKickCounts.size();
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvPatientName, tvKickCount;

            ViewHolder(View itemView) {
                super(itemView);
                tvPatientName = itemView.findViewById(R.id.tvPatientName);
                tvKickCount = itemView.findViewById(R.id.tvKickCount);
            }
        }
    }

    // Data class for patient name and kick count
    private static class PatientKickCount {
        String name;
        int kickCount;

        PatientKickCount(String name, int kickCount) {
            this.name = name;
            this.kickCount = kickCount;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_patient_kickcount);

        recyclerView = findViewById(R.id.recyclerViewKickCounts);
        patientKickCounts = new ArrayList<>();

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        kickCountAdapter = new KickCountAdapter(patientKickCounts);
        recyclerView.setAdapter(kickCountAdapter);

        fetchKickCounts();
    }

    private void fetchKickCounts() {
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(FETCH_URL);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                int responseCode = conn.getResponseCode();
                Log.d(TAG, "Server response code: " + responseCode);

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder result = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        result.append(line);
                    }
                    reader.close();

                    String rawResponse = result.toString();
                    Log.d(TAG, "Raw response from server: " + rawResponse);

                    JSONArray jsonArray = new JSONArray(rawResponse);
                    List<PatientKickCount> fetchedKickCounts = new ArrayList<>();

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject patient = jsonArray.getJSONObject(i);
                        String fullName = patient.optString("firstName", "N/A") + " " +
                                patient.optString("lastName", "N/A");
                        int kickCount = patient.optInt("kick_count", 0);

                        fetchedKickCounts.add(new PatientKickCount(fullName, kickCount));
                    }

                    runOnUiThread(() -> {
                        patientKickCounts.clear();
                        patientKickCounts.addAll(fetchedKickCounts);
                        kickCountAdapter.notifyDataSetChanged();
                        if (patientKickCounts.isEmpty()) {
                            Toast.makeText(this, "No kick counts found", Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    String errorMsg = "Server error: " + responseCode;
                    if (responseCode == 404) {
                        errorMsg = "Server error: Resource not found (404). Check URL: " + FETCH_URL;
                    }
                    final String finalErrorMsg = errorMsg;
                    runOnUiThread(() -> Toast.makeText(this, finalErrorMsg, Toast.LENGTH_LONG).show());
                    Log.e(TAG, errorMsg);
                }
            } catch (Exception e) {
                Log.e(TAG, "Error fetching kick counts: " + e.getMessage(), e);
                runOnUiThread(() -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show());
            } finally {
                if (conn != null) {
                    conn.disconnect();
                }
            }
        }).start();
    }
}