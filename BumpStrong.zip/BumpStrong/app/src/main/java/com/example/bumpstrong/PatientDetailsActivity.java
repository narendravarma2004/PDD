package com.example.bumpstrong;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class PatientDetailsActivity extends AppCompatActivity {
    private EditText etFirstName, etLastName, etAge, etEducation, etOccupation, etPhone,
            etBloodGroup, etLmpDate, etDueDate, etWeight, etHeight, etObstetricsScore,
            etMaritalStatus;
    private RadioGroup rgAbortion, rgRelativeToHusband, rgPregnancyConfirmed;
    private Button btnSave;
    private final Calendar calendar = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_details);

        // Initializing EditTexts
        etFirstName = findViewById(R.id.etFirstName);
        etLastName = findViewById(R.id.etLastName);
        etAge = findViewById(R.id.etAge);
        etEducation = findViewById(R.id.etEducation);
        etOccupation = findViewById(R.id.etOccupation);
        etPhone = findViewById(R.id.etPhone);
        etBloodGroup = findViewById(R.id.etBloodGroup);
        etLmpDate = findViewById(R.id.etLmpDate);
        etDueDate = findViewById(R.id.etDueDate);
        rgAbortion = findViewById(R.id.rgAbortion);
        rgRelativeToHusband = findViewById(R.id.rgRelativeToHusband);
        rgPregnancyConfirmed = findViewById(R.id.rgPregnancyConfirmed);
        etWeight = findViewById(R.id.etWeight);
        etHeight = findViewById(R.id.etHeight);
        etObstetricsScore = findViewById(R.id.etObstetricsScore);
        etMaritalStatus = findViewById(R.id.etMaritalStatus);
        btnSave = findViewById(R.id.btnSave);

        // Date Picker for LMP Date
        etLmpDate.setOnClickListener(v -> showDatePickerDialog());

        // Save Button Click Event
        btnSave.setOnClickListener(v -> sendPatientData());
    }

    private void showDatePickerDialog() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            calendar.set(year, month, dayOfMonth);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            etLmpDate.setText(sdf.format(calendar.getTime()));
            calculateDueDate();
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    private void calculateDueDate() {
        Calendar dueDateCalendar = (Calendar) calendar.clone();
        dueDateCalendar.add(Calendar.DAY_OF_YEAR, 280); // Adding 40 weeks (280 days)
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        etDueDate.setText(sdf.format(dueDateCalendar.getTime()));
    }

    private void sendPatientData() {
        try {
            // Get user input
            String firstName = etFirstName.getText().toString().trim();
            String lastName = etLastName.getText().toString().trim();
            String age = etAge.getText().toString().trim();
            String education = etEducation.getText().toString().trim();
            String occupation = etOccupation.getText().toString().trim();
            String phone = etPhone.getText().toString().trim();
            String bloodGroup = etBloodGroup.getText().toString().trim();
            String lmpDate = etLmpDate.getText().toString().trim();
            String dueDate = etDueDate.getText().toString().trim();

            String abortionHistory = "";
            int abortionId = rgAbortion.getCheckedRadioButtonId();
            if (abortionId != -1) {
                abortionHistory = ((RadioButton)findViewById(abortionId)).getText().toString();
            }

            String relativeToHusband = "";
            int relativeId = rgRelativeToHusband.getCheckedRadioButtonId();
            if (relativeId != -1) {
                relativeToHusband = ((RadioButton)findViewById(relativeId)).getText().toString();
            }

            String confirmationOfPregnancy = "";
            int pregnancyId = rgPregnancyConfirmed.getCheckedRadioButtonId();
            if (pregnancyId != -1) {
                confirmationOfPregnancy = ((RadioButton)findViewById(pregnancyId)).getText().toString();
            }

            String weight = etWeight.getText().toString().trim();
            String height = etHeight.getText().toString().trim();
            String obstetricsScore = etObstetricsScore.getText().toString().trim();
            String maritalStatus = etMaritalStatus.getText().toString().trim();

            // Basic validation
            if (firstName.isEmpty() || lastName.isEmpty() || phone.isEmpty()) {
                Toast.makeText(this, "Please fill in all required fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Create JSON object
            JSONObject postData = new JSONObject();
            postData.put("firstName", firstName);
            postData.put("lastName", lastName);
            postData.put("age", age);
            postData.put("education", education);
            postData.put("occupation", occupation);
            postData.put("phoneNumber", phone);
            postData.put("bloodGroup", bloodGroup);
            postData.put("lmpDate", lmpDate);
            postData.put("dueDate", dueDate);
            postData.put("abortionHistory", abortionHistory);
            postData.put("relativeToHusband", relativeToHusband);
            postData.put("confirmationOfPregnancy", confirmationOfPregnancy);
            postData.put("weight", weight);
            postData.put("Height", height);
            postData.put("obstetricScore", obstetricsScore);
            postData.put("maritalStatus", maritalStatus);

            // Define API URL
            String apiUrl = "http://192.168.85.64/bumpstrong/createpatients.php";

            // Send data to API
            ApiHandler.sendPatientData(apiUrl, postData, response -> {
                runOnUiThread(() -> {
                    Toast.makeText(PatientDetailsActivity.this, response, Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(PatientDetailsActivity.this, QuestionariesActivity.class);
                    startActivity(intent);
                    finish();
                });
            });

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}