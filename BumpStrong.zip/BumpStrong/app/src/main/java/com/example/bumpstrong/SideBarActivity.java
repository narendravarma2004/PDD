package com.example.bumpstrong;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class SideBarActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sidebar);

        // Initialize buttons
        Button btnProfile = findViewById(R.id.btn_profile);
        Button btnTasks = findViewById(R.id.btn_tasks);
        Button btnVideos = findViewById(R.id.btn_videos);
        Button btnProgress = findViewById(R.id.btn_progress);
        Button btnDangerSigns = findViewById(R.id.btn_danger_signs);
        Button btnKickCount = findViewById(R.id.btn_kick_count);
        Button btnDelivery = findViewById(R.id.btn_delivery);
        Button btnNotifications = findViewById(R.id.btn_notifications);
        Button btnLogout = findViewById(R.id.btn_logout);

        // Set click listeners for navigation
        btnProfile.setOnClickListener(v -> navigateTo(PatientProfileActivity.class));
        btnTasks.setOnClickListener(v -> navigateTo(TasksActivity.class));
        btnVideos.setOnClickListener(v -> navigateTo(TrimesterChooseActivity.class));
        btnProgress.setOnClickListener(v -> navigateTo(DailyProgressActivity.class));
        btnDangerSigns.setOnClickListener(v -> navigateTo(DangerSignsActivity.class));
        btnKickCount.setOnClickListener(v -> navigateTo(KickCountActivity.class));
        btnDelivery.setOnClickListener(v -> navigateTo(DeliveryOutcomeActivity.class));
        btnNotifications.setOnClickListener(v -> navigateTo(NotificationsActivity.class));

        // Logout button
        btnLogout.setOnClickListener(v -> {
            // Perform logout actions (clear session, go to login screen)
            Intent intent = new Intent(SideBarActivity.this, PatientLoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    // Function to navigate to another activity
    private void navigateTo(Class<?> targetActivity) {
        Intent intent = new Intent(SideBarActivity.this, targetActivity);
        startActivity(intent);
    }
}
