package com.example.bumpstrong;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class QuestionariesActivity extends AppCompatActivity {

    private ImageView btnBack;
    private Button btnProceed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questionaries);

        // Initialize UI elements
        btnBack = findViewById(R.id.btnBack);
        btnProceed = findViewById(R.id.btnProceed);

        // Back button functionality
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Go back
            }
        });

        // Proceed button functionality
        btnProceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(QuestionariesActivity.this, PatientSignUpActivity.class); // Change to your target activity
                startActivity(intent);
            }
        });
    }
}
