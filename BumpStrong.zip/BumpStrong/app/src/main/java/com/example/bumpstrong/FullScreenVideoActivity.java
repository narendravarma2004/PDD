package com.example.bumpstrong;

import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.MediaController;
import android.widget.VideoView;
import androidx.appcompat.app.AppCompatActivity;

public class FullScreenVideoActivity extends AppCompatActivity {
    VideoView fullScreenVideoView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set fullscreen flags
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_full_screen_video);

        fullScreenVideoView = findViewById(R.id.fullScreenVideoView);
        String videoUrl = getIntent().getStringExtra("video_url");

        if (videoUrl != null) {
            fullScreenVideoView.setVideoPath(videoUrl);
            MediaController mediaController = new MediaController(this);
            mediaController.setAnchorView(fullScreenVideoView);
            fullScreenVideoView.setMediaController(mediaController);
            fullScreenVideoView.start();
        }
    }

    @Override
    public void onBackPressed() {
        fullScreenVideoView.stopPlayback();
        Intent intent = new Intent(this, VideosActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }
}