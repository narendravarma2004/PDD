package com.example.bumpstrong;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class NotificationsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private NotificationAdapter adapter;
    private List<NotificationItem> notificationList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Sample notifications
        notificationList = new ArrayList<>();
        notificationList.add(new NotificationItem("Appointment Reminder", "You have a check-up scheduled for tomorrow at 10 AM.", "10 mins ago"));
        notificationList.add(new NotificationItem("New Exercise Added", "A new prenatal yoga exercise has been added for you.", "1 hour ago"));
        notificationList.add(new NotificationItem("Kick Count Reminder", "Don’t forget to record today’s baby movements.", "2 hours ago"));

        adapter = new NotificationAdapter(notificationList);
        recyclerView.setAdapter(adapter);
    }
}
