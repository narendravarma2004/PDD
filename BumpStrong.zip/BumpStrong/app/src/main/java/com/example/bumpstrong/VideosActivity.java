package com.example.bumpstrong;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class VideosActivity extends AppCompatActivity {
    ListView videoListView;
    String videoURL = "http://192.168.85.64/bumpstrong/fetch_videos.php";
    ArrayList<String> videoNames = new ArrayList<>();
    ArrayList<String> videoPaths = new ArrayList<>();
    ArrayList<String> thumbnailPaths = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_videos);

        videoListView = findViewById(R.id.videoListView);
        new FetchVideoTask().execute();

        videoListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(VideosActivity.this, FullScreenVideoActivity.class);
                intent.putExtra("video_url", videoPaths.get(position));
                startActivity(intent);
            }
        });
    }

    private class FetchVideoTask extends AsyncTask<Void, Void, String> {
        ProgressDialog progressDialog = new ProgressDialog(VideosActivity.this);

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setMessage("Loading videos...");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(Void... voids) {
            try {
                URL url = new URL(videoURL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                InputStream inputStream = conn.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder result = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }

                reader.close();
                return result.toString();
            } catch (Exception e) {
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            progressDialog.dismiss();

            if (result != null) {
                try {
                    JSONArray jsonArray = new JSONArray(result);
                    if (jsonArray.length() > 0) {
                        videoNames.clear();
                        videoPaths.clear();
                        thumbnailPaths.clear();

                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject videoObject = jsonArray.getJSONObject(i);
                            videoNames.add(videoObject.getString("video_name"));
                            videoPaths.add(videoObject.getString("video_path"));
                            thumbnailPaths.add(videoObject.getString("thumbnail_path"));
                        }

                        VideoListAdapter adapter = new VideoListAdapter(VideosActivity.this, videoNames);
                        videoListView.setAdapter(adapter);
                    } else {
                        Toast.makeText(VideosActivity.this, "No videos found", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    Toast.makeText(VideosActivity.this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(VideosActivity.this, "Error fetching videos", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private class VideoListAdapter extends ArrayAdapter<String> {
        public VideoListAdapter(Context context, ArrayList<String> videos) {
            super(context, 0, videos);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(android.R.layout.simple_list_item_1, parent, false);
            }

            TextView textView = convertView.findViewById(android.R.id.text1);
            textView.setText(getItem(position));
            textView.setTextColor(getResources().getColor(android.R.color.black));
            convertView.setBackgroundColor(getResources().getColor(android.R.color.white));

            return convertView;
        }
    }
}