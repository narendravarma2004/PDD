package com.example.bumpstrong;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class PatientLoginActivity extends AppCompatActivity {

    private EditText etUsername, etPassword;
    private Button btnLogin;
    private TextView tvSignup;
    private ImageView backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_patient);

        etUsername = findViewById(R.id.etPatientId);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvSignup = findViewById(R.id.tvSignup);
        backButton = findViewById(R.id.backButton);

        btnLogin.setOnClickListener(v -> {
            String username = etUsername.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(PatientLoginActivity.this, "Please enter Username and Password", Toast.LENGTH_SHORT).show();
            } else {
                new LoginTask().execute(username, password);
            }
        });

        tvSignup.setOnClickListener(v -> {
            Intent intent = new Intent(PatientLoginActivity.this, PatientDetailsActivity.class);
            startActivity(intent);
        });

        backButton.setOnClickListener(v -> finish());
    }

    private class LoginTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            HttpURLConnection conn = null;
            try {
                String apiUrl = "http://192.168.85.64/bumpstrong/Patient.php";
                URL url = new URL(apiUrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setDoInput(true);
                conn.setRequestProperty("Content-Type", "application/json");

                JSONObject postData = new JSONObject();
                postData.put("username", params[0]);
                postData.put("password", params[1]);

                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream(), "UTF-8"));
                writer.write(postData.toString());
                writer.flush();
                writer.close();

                InputStream inputStream = conn.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();
                return response.toString();
            } catch (Exception e) {
                return "{\"status\":\"error\",\"message\":\"Connection failed: " + e.getMessage() + "\"}";
            } finally {
                if (conn != null) conn.disconnect();
            }
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                JSONObject jsonResponse = new JSONObject(result);
                if (jsonResponse.getString("status").equals("success")) {
                    String patientId = jsonResponse.getString("patient_id");

                    // Save to SharedPreferences
                    SharedPreferences sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("patient_id", patientId);
                    editor.apply();

                    // Pass patient_id to PatientHomeActivity via Intent
                    Intent intent = new Intent(PatientLoginActivity.this, PatientHomeActivity.class);
                    intent.putExtra("PATIENT_ID", patientId);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(PatientLoginActivity.this, "Login Failed: " + jsonResponse.getString("message"), Toast.LENGTH_LONG).show();
                }
            } catch (JSONException e) {
                Toast.makeText(PatientLoginActivity.this, "Error parsing response: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }
}
