package com.example.bumpstrong;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class PatientDetailsShowActivity extends AppCompatActivity {

    private TextView tvPatientId, tvName, tvAge, tvEducation, tvOccupation, tvPhoneNumber,
            tvBloodGroup, tvLmpDate, tvDueDate, tvAbortionHistory, tvRelativeToHusband,
            tvConfirmationOfPregnancy, tvWeight, tvHeight, tvObstetricScore, tvMaritalStatus;
    private static final String TAG = "PatientDetails";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_details_show);

        // Initialize TextViews
        tvPatientId = findViewById(R.id.tvPatientId);
        tvName = findViewById(R.id.tvName);
        tvAge = findViewById(R.id.tvAge);
        tvEducation = findViewById(R.id.tvEducation);
        tvOccupation = findViewById(R.id.tvOccupation);
        tvPhoneNumber = findViewById(R.id.tvPhoneNumber);
        tvBloodGroup = findViewById(R.id.tvBloodGroup);
        tvLmpDate = findViewById(R.id.tvLmpDate);
        tvDueDate = findViewById(R.id.tvDueDate);
        tvAbortionHistory = findViewById(R.id.tvAbortionHistory);
        tvRelativeToHusband = findViewById(R.id.tvRelativeToHusband);
        tvConfirmationOfPregnancy = findViewById(R.id.tvConfirmationOfPregnancy);
        tvWeight = findViewById(R.id.tvWeight);
        tvHeight = findViewById(R.id.tvHeight);
        tvObstetricScore = findViewById(R.id.tvObstetricScore);
        tvMaritalStatus = findViewById(R.id.tvMaritalStatus);

        // Get patient_id from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        String patientId = sharedPreferences.getString("patient_id", "");

        if (patientId == null || patientId.isEmpty()) {
            Toast.makeText(this, "No patient ID found. Please log in again.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        Log.d(TAG, "Fetching details for patient_id: " + patientId);
        fetchPatientDetails(patientId);
    }

    private void fetchPatientDetails(String patientId) {
        new Thread(() -> {
            try {
                String encodedPatientId = URLEncoder.encode(patientId, "UTF-8");
                URL url = new URL("http://192.168.85.64/bumpstrong/fetch_patient.php?patient_id=" + encodedPatientId);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                int responseCode = conn.getResponseCode();
                if (responseCode != HttpURLConnection.HTTP_OK) {
                    throw new Exception("Server error: " + responseCode);
                }

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder result = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }
                reader.close();
                conn.disconnect();

                Log.d(TAG, "Server response: " + result);
                JSONObject jsonObject = new JSONObject(result.toString());

                runOnUiThread(() -> updateUI(jsonObject));
            } catch (Exception e) {
                Log.e(TAG, "Error fetching patient details", e);
                runOnUiThread(() ->
                        Toast.makeText(this, "Error fetching details. Check internet connection.", Toast.LENGTH_LONG).show()
                );
            }
        }).start();
    }

    private void updateUI(JSONObject jsonObject) {
        try {
            if (jsonObject.has("error")) {
                Toast.makeText(this, jsonObject.getString("error"), Toast.LENGTH_LONG).show();
                return;
            }

            JSONObject patient = jsonObject.getJSONObject("patient");

            tvPatientId.setText(patient.optString("patient_id", "N/A"));
            tvName.setText(formatName(patient.optString("firstName", "N/A"), patient.optString("lastName", "N/A")));
            tvAge.setText(patient.optString("age", "N/A") + " years");
            tvEducation.setText(patient.optString("education", "N/A"));
            tvOccupation.setText(patient.optString("occupation", "N/A"));
            tvPhoneNumber.setText(patient.optString("phoneNumber", "N/A"));
            tvBloodGroup.setText(patient.optString("bloodGroup", "N/A"));
            tvLmpDate.setText(patient.optString("lmpDate", "N/A"));
            tvDueDate.setText(patient.optString("dueDate", "N/A"));
            tvAbortionHistory.setText(patient.optString("abortionHistory", "N/A"));
            tvRelativeToHusband.setText(patient.optString("relativeToHusband", "N/A"));
            tvConfirmationOfPregnancy.setText(patient.optString("confirmationOfPregnancy", "N/A"));
            tvWeight.setText(String.format("%.1f kg", patient.optDouble("weight", 0.0)));
            tvHeight.setText(String.format("%.1f cm", patient.optDouble("height", 0.0)));
            tvObstetricScore.setText(String.valueOf(patient.optInt("obstetricScore", 0)));
            tvMaritalStatus.setText(patient.optString("maritalStatus", "N/A"));

        } catch (JSONException e) {
            Log.e(TAG, "Error parsing JSON", e);
            Toast.makeText(this, "Error parsing data", Toast.LENGTH_SHORT).show();
        }
    }

    private String formatName(String firstName, String lastName) {
        return firstName + " " + lastName;
    }
}
