package com.example.bumpstrong;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "bumpstrong";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Table is assumed to exist already
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle upgrades
    }

    public List<ProgressModel> getPatientProgress() {
        List<ProgressModel> progressList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM progress", null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String patientId = cursor.getString(1);
                String taskDate = cursor.getString(2);
                int completed = cursor.getInt(3);

                progressList.add(new ProgressModel(id, patientId, taskDate, completed));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        return progressList;
    }
}
