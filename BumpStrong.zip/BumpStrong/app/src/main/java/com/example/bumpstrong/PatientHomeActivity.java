package com.example.bumpstrong;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class PatientHomeActivity extends AppCompatActivity {

    private TextView tvTrimester, tvWeeks, tvDays, tvMonth;
    private ImageView menuIcon, profileIcon, notificationIcon;
    private ViewPager2 bannerViewPager;
    private SharedPreferences sharedPreferences;
    private long backPressedTime;
    private static final String TAG = "PatientHomeActivity";
    private static final String BASE_URL = "http://192.168.85.64/bumpstrong/";
    private Handler handler;
    private Runnable runnable;
    private final List<Integer> bannerImages = Arrays.asList(
            R.drawable.banner1,
            R.drawable.banner2,
            R.drawable.banner3,
            R.drawable.banner4
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_home);
        if (getIntent().getBooleanExtra("TASKS_COMPLETED", false)) {
            Toast.makeText(this, "Congratulations! All daily tasks completed!", Toast.LENGTH_LONG).show();
        }

        // Initialize TextViews
        tvTrimester = findViewById(R.id.trimester_text);
        tvMonth = findViewById(R.id.month_text);
        tvWeeks = findViewById(R.id.week_text);
        tvDays = findViewById(R.id.day_text);

        // Initialize Icons
        menuIcon = findViewById(R.id.menu_icon);
        profileIcon = findViewById(R.id.profile_icon);
        notificationIcon = findViewById(R.id.notification_icon);

        // Initialize Banner
        bannerViewPager = findViewById(R.id.banner_viewpager);

        // Initialize Tool Buttons
        View reminder = findViewById(R.id.reminder);
        View exercise = findViewById(R.id.exercise);
        View videos = findViewById(R.id.videos);
        View outcome = findViewById(R.id.outcome);
        View kickcount = findViewById(R.id.kickcount);
        View danger = findViewById(R.id.danger);
        View reports = findViewById(R.id.reports);

        sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        String patientId = sharedPreferences.getString("patient_id", null);

        // Setup Banner Slider
        setupBannerSlider();

        // Set Click Listeners for Header Icons
        menuIcon.setOnClickListener(v -> startActivity(new Intent(this, SideBarActivity.class)));
        profileIcon.setOnClickListener(v -> startActivity(new Intent(this, PatientProfileActivity.class)));
        notificationIcon.setOnClickListener(v -> startActivity(new Intent(this, RemActivity.class)));

        // Set Click Listener for Tools
        View.OnClickListener toolListener = v -> {
            Intent intent = null;
            if (v.getId() == R.id.reminder) intent = new Intent(this, TasksActivity.class);
            else if (v.getId() == R.id.exercise) intent = new Intent(this, VideosRecommendationActivity.class);
            else if (v.getId() == R.id.videos) intent = new Intent(this, TrimesterChooseActivity.class);
            else if (v.getId() == R.id.outcome) intent = new Intent(this, DeliveryOutcomeActivity.class);
            else if (v.getId() == R.id.kickcount) intent = new Intent(this, KickCountActivity.class);
            else if (v.getId() == R.id.danger) intent = new Intent(this, DangerSignsActivity.class);
            else if (v.getId() == R.id.reports) intent = new Intent(this, UploadReportActivity.class);

            if (intent != null) {
                startActivity(intent);
            }
        };

        // Apply listener to all tool buttons
        reminder.setOnClickListener(toolListener);
        exercise.setOnClickListener(toolListener);
        videos.setOnClickListener(toolListener);
        outcome.setOnClickListener(toolListener);
        kickcount.setOnClickListener(toolListener);
        danger.setOnClickListener(toolListener);
        reports.setOnClickListener(toolListener);

        // Fetch patient details
        if (patientId != null && !patientId.isEmpty()) {
            fetchPatientDetails(patientId);
        } else {
            Toast.makeText(this, "Please log in again", Toast.LENGTH_LONG).show();
            setNoDataUI();
        }
    }

    private void setupBannerSlider() {
        BannerAdapter adapter = new BannerAdapter(bannerImages);
        bannerViewPager.setAdapter(adapter);

        // Auto-scroll
        handler = new Handler(Looper.getMainLooper());
        runnable = new Runnable() {
            @Override
            public void run() {
                int currentItem = bannerViewPager.getCurrentItem();
                int nextItem = (currentItem + 1) % bannerImages.size();
                bannerViewPager.setCurrentItem(nextItem, true);
                handler.postDelayed(this, 3000); // Change every 3 seconds
            }
        };
        handler.postDelayed(runnable, 3000);
    }

    private void fetchPatientDetails(String patientId) {
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                String encodedPatientId = URLEncoder.encode(patientId, "UTF-8");
                String apiUrl = BASE_URL + "fetch_patient.php?patient_id=" + encodedPatientId;
                URL url = new URL(apiUrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);
                conn.setDoInput(true);

                int responseCode = conn.getResponseCode();
                if (responseCode != HttpURLConnection.HTTP_OK) {
                    throw new Exception("HTTP error code: " + responseCode);
                }

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                Log.d(TAG, "Response: " + response.toString());

                JSONObject jsonObject = new JSONObject(response.toString());
                if (jsonObject.has("success") && !jsonObject.getBoolean("success")) {
                    runOnUiThread(() -> Toast.makeText(this, jsonObject.optString("message", "No data available"), Toast.LENGTH_LONG).show());
                    return;
                }

                if (jsonObject.has("patient")) {
                    JSONObject patientData = jsonObject.getJSONObject("patient");
                    String lmpDate = patientData.optString("lmpDate", "");
                    if (!lmpDate.isEmpty()) {
                        calculatePregnancyDetails(lmpDate);
                    } else {
                        runOnUiThread(this::setNoDataUI);
                    }
                } else {
                    runOnUiThread(this::setNoDataUI);
                }

            } catch (Exception e) {
                Log.e(TAG, "Error fetching details", e);
                runOnUiThread(() -> Toast.makeText(this, "Error fetching details", Toast.LENGTH_SHORT).show());
            } finally {
                if (conn != null) {
                    conn.disconnect();
                }
            }
        }).start();
    }

    private void calculatePregnancyDetails(String lmpDate) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            Date startDate = sdf.parse(lmpDate);
            Date currentDate = new Date();

            long diffInMillis = currentDate.getTime() - startDate.getTime();
            long daysElapsed = TimeUnit.DAYS.convert(diffInMillis, TimeUnit.MILLISECONDS);
            long weeksElapsed = daysElapsed / 7;
            long daysRemaining = daysElapsed % 7;
            long monthsElapsed = weeksElapsed / 4;  // Approximate month calculation
            int trimester = (weeksElapsed < 13) ? 1 : (weeksElapsed < 27) ? 2 : 3;

            runOnUiThread(() -> {
                tvTrimester.setText(String.valueOf(trimester));
                tvMonth.setText(String.valueOf(monthsElapsed));
                tvWeeks.setText(String.valueOf(weeksElapsed));
                tvDays.setText(String.valueOf(daysRemaining));
            });

        } catch (Exception e) {
            Log.e(TAG, "Error parsing LMP date", e);
            runOnUiThread(() -> Toast.makeText(this, "Error calculating pregnancy details", Toast.LENGTH_SHORT).show());
        }
    }

    @Override
    public void onBackPressed() {
        if (backPressedTime + 2000 > System.currentTimeMillis()) {
            finishAffinity();
        } else {
            Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT).show();
        }
        backPressedTime = System.currentTimeMillis();
    }


    private void setNoDataUI() {
        runOnUiThread(() -> {
            tvTrimester.setText("N/A");
            tvMonth.setText("N/A");
            tvWeeks.setText("N/A");
            tvDays.setText("N/A");
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (handler != null && runnable != null) {
            handler.removeCallbacks(runnable);
        }
    }

    // Banner Adapter
    private class BannerAdapter extends RecyclerView.Adapter<BannerAdapter.BannerViewHolder> {
        private final List<Integer> images;

        BannerAdapter(List<Integer> images) {
            this.images = images;
        }

        @Override
        public BannerViewHolder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            ImageView imageView = new ImageView(parent.getContext());
            imageView.setLayoutParams(new ViewPager2.LayoutParams(
                    ViewPager2.LayoutParams.MATCH_PARENT,
                    ViewPager2.LayoutParams.MATCH_PARENT
            ));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            return new BannerViewHolder(imageView);
        }

        @Override
        public void onBindViewHolder(BannerViewHolder holder, int position) {
            holder.imageView.setImageResource(images.get(position));
        }

        @Override
        public int getItemCount() {
            return images.size();
        }

        class BannerViewHolder extends RecyclerView.ViewHolder {
            ImageView imageView;

            BannerViewHolder(ImageView itemView) {
                super(itemView);
                this.imageView = itemView;
            }
        }
    }
}