package com.example.bumpstrong;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MedicalHistoryActivity extends AppCompatActivity {

    private RadioGroup aphGroup, heartGroup, multipleGroup, hypertensionGroup, csectionGroup,
            seizureGroup, traumaPregnancyGroup, traumaGroup, lungsHeartGroup, abdominalGroup,
            pelvicGroup, spineGroup, kneeLegGroup, cervixGroup;
    private EditText otherConditionsInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medical_history);

        // Initialize UI elements
        initializeViews();

        // Back button
        ImageView btnBack = findViewById(R.id.btn_back);
        btnBack.setOnClickListener(v -> finish());

        // Save button
        Button btnSave = findViewById(R.id.btnSave);
        btnSave.setOnClickListener(v -> saveMedicalHistory());
    }

    private void initializeViews() {
        aphGroup = findViewById(R.id.aphGroup);
        heartGroup = findViewById(R.id.heartGroup);
        multipleGroup = findViewById(R.id.multipleGroup);
        hypertensionGroup = findViewById(R.id.hypertensionGroup);
        csectionGroup = findViewById(R.id.csectionGroup);
        seizureGroup = findViewById(R.id.seizureGroup);
        traumaPregnancyGroup = findViewById(R.id.traumaPregnancyGroup);
        traumaGroup = findViewById(R.id.traumaGroup);
        lungsHeartGroup = findViewById(R.id.lungsHeartGroup);
        abdominalGroup = findViewById(R.id.abdominalGroup);
        pelvicGroup = findViewById(R.id.pelvicGroup);
        spineGroup = findViewById(R.id.spineGroup);
        kneeLegGroup = findViewById(R.id.kneeLegGroup);
        cervixGroup = findViewById(R.id.CervixGroup);
        otherConditionsInput = findViewById(R.id.otherConditionsInput);
    }

    private void saveMedicalHistory() {
        // Example: Collect data from RadioGroups and EditText
        String aph = getRadioButtonText(aphGroup, R.id.aphYes);
        String heart = getRadioButtonText(heartGroup, R.id.heartYes);
        String multiple = getRadioButtonText(multipleGroup, R.id.multipleYes);
        String hypertension = getRadioButtonText(hypertensionGroup, R.id.hypertensionYes);
        String csection = getRadioButtonText(csectionGroup, R.id.csectionYes);
        String seizure = getRadioButtonText(seizureGroup, R.id.seizureYes);
        String traumaPregnancy = getRadioButtonText(traumaPregnancyGroup, R.id.traumaPregnancyYes);
        String trauma = getRadioButtonText(traumaGroup, R.id.traumaYes);
        String lungsHeart = getRadioButtonText(lungsHeartGroup, R.id.lungsHeartYes);
        String abdominal = getRadioButtonText(abdominalGroup, R.id.abdominalYes);
        String pelvic = getRadioButtonText(pelvicGroup, R.id.pelvicYes);
        String spine = getRadioButtonText(spineGroup, R.id.spineYes);
        String kneeLeg = getRadioButtonText(kneeLegGroup, R.id.kneeLegYes);
        String cervix = getRadioButtonText(cervixGroup, R.id.CervixYes);
        String otherConditions = otherConditionsInput.getText().toString();

        // Placeholder for saving logic (e.g., to SharedPreferences or database)
        Toast.makeText(this, "Medical History Saved:\nAPH: " + aph + "\nOther Conditions: " + otherConditions,
                Toast.LENGTH_LONG).show();
    }

    private String getRadioButtonText(RadioGroup group, int yesId) {
        int checkedId = group.getCheckedRadioButtonId();
        if (checkedId == yesId) return "Yes";
        if (checkedId != -1) return "No";
        return "Not specified";
    }
}