package com.example.bumpstrong;

public class VideoItem {
    private String title;
    private String videoUrl;
    private String thumbnailUrl;

    public VideoItem(String title, String videoUrl, String thumbnailUrl) {
        this.title = title;
        this.videoUrl = videoUrl;
        this.thumbnailUrl = thumbnailUrl;
    }

    public String getTitle() {
        return title;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }
}
