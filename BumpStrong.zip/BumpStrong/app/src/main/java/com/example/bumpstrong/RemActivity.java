package com.example.bumpstrong;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RemActivity extends AppCompatActivity {
    private TextView tvPatientId, tvLmpDate, tvWeeks;
    private RecyclerView rvReminders;
    private Button btnRefresh;
    private SharedPreferences prefs;
    private String patientId;
    private ReminderAdapter reminderAdapter;
    private static final String PREFS_NAME = "LoginPrefs";
    private static final String PATIENT_ID_KEY = "patient_id";
    private static final String BASE_URL = "http://192.168.85.64/bumpstrong/fetch_date.php?patient_id=";
    private static final String TAG = "RemActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rem);

        // Initialize UI components
        tvPatientId = findViewById(R.id.tvPatientId);
        tvLmpDate = findViewById(R.id.tvLmpDate);
        tvWeeks = findViewById(R.id.tvWeeks);
        rvReminders = findViewById(R.id.rvReminders);
        btnRefresh = findViewById(R.id.btnRefresh);

        // Setup RecyclerView
        reminderAdapter = new ReminderAdapter();
        rvReminders.setLayoutManager(new LinearLayoutManager(this));
        rvReminders.setAdapter(reminderAdapter);

        // Initialize SharedPreferences
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Get patientId
        patientId = getIntent().getStringExtra("PATIENT_ID");
        if (patientId == null || patientId.isEmpty()) {
            patientId = prefs.getString(PATIENT_ID_KEY, null);
            if (patientId == null || patientId.isEmpty()) {
                Log.e(TAG, "No patientId found");
                tvPatientId.setText("Error: No Patient ID");
                return;
            }
        }
        Log.d(TAG, "Using patientId: " + patientId);
        tvPatientId.setText("Patient ID: " + patientId);

        // Initial data fetch
        clearUiData();
        fetchPregnancyData(patientId);

        // Refresh button listener
        btnRefresh.setOnClickListener(v -> {
            clearUiData();
            fetchPregnancyData(patientId);
        });
    }

    private void clearUiData() {
        tvLmpDate.setText("LMP Date: Loading...");
        tvWeeks.setText("Weeks Pregnant: Calculating...");
        reminderAdapter.updateReminders(new ArrayList<>());
    }

    private void fetchPregnancyData(String patientId) {
        Log.d(TAG, "Fetching data for patientId: " + patientId);
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(BASE_URL + patientId);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();
                conn.disconnect();

                String responseStr = response.toString();
                Log.d(TAG, "Server response: " + responseStr);
                JSONObject json = new JSONObject(responseStr);
                String lmpDateStr = json.getJSONObject("patient").getString("lmpDate");

                runOnUiThread(() -> {
                    tvLmpDate.setText("LMP Date: " + lmpDateStr);
                    calculatePregnancyWeeks(lmpDateStr);
                });

            } catch (Exception e) {
                Log.e(TAG, "Error fetching data: " + e.getMessage());
                runOnUiThread(() -> {
                    List<Reminder> errorList = new ArrayList<>();
                    errorList.add(new Reminder("Error fetching data: " + e.getMessage(), "N/A", false));
                    reminderAdapter.updateReminders(errorList);
                });
            }
        });
    }

    private void calculatePregnancyWeeks(String lmpDateStr) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date lmpDate = sdf.parse(lmpDateStr);
            Date currentDate = new Date();

            long diffInMillies = currentDate.getTime() - lmpDate.getTime();
            int weeks = (int) (diffInMillies / (1000 * 60 * 60 * 24 * 7));
            Log.d(TAG, "Calculated weeks: " + weeks);

            tvWeeks.setText("Weeks Pregnant: " + weeks);
            updateReminders(weeks);

        } catch (Exception e) {
            Log.e(TAG, "Error calculating weeks: " + e.getMessage());
            tvWeeks.setText("Error calculating weeks");
            List<Reminder> errorList = new ArrayList<>();
            errorList.add(new Reminder("Error: " + e.getMessage(), "N/A", false));
            reminderAdapter.updateReminders(errorList);
        }
    }

    private void updateReminders(int weeks) {
        List<Reminder> reminders = new ArrayList<>();
        String currentTime = new SimpleDateFormat("HH:mm").format(new Date());

        if (weeks < 12) { // First Trimester
            reminders.add(new Reminder("Schedule first prenatal visit", "08:00", false));
            reminders.add(new Reminder("Start prenatal vitamins", "09:00", false));
            reminders.add(new Reminder("Avoid alcohol and smoking", "All day", false));
            reminders.add(new Reminder("First trimester scan", "10:00", false, true));
            reminders.add(new Reminder("Blood tests", "11:00", false));
        } else if (weeks < 20) { // Second Trimester (early)
            reminders.add(new Reminder("Anatomy scan", "09:30", false, true));
            reminders.add(new Reminder("Monitor fetal movements", "Daily", false));
            reminders.add(new Reminder("Maintain healthy diet", "All day", false));
            reminders.add(new Reminder("Prenatal yoga", "15:00", false));
            reminders.add(new Reminder("Dental check-up", "14:00", false));
        } else if (weeks < 28) { // Second Trimester (late)
            reminders.add(new Reminder("Glucose screening", "08:30", false));
            reminders.add(new Reminder("Growth scan", "10:00", false, true));
            reminders.add(new Reminder("Childbirth classes", "16:00", false));
            reminders.add(new Reminder("Plan maternity leave", "All day", false));
            reminders.add(new Reminder("Iron supplements", "09:00", false));
        } else { // Third Trimester
            reminders.add(new Reminder("Pack hospital bag", "All day", false));
            reminders.add(new Reminder("Install car seat", "All day", false));
            reminders.add(new Reminder("Final growth scan", "09:00", false, true));
            reminders.add(new Reminder("Finalize birth plan", "All day", false));
            reminders.add(new Reminder("Weekly check-ups", "10:00", false));
            reminders.add(new Reminder("Practice breathing exercises", "20:00", false));
        }

        reminderAdapter.updateReminders(reminders);
    }

    // Reminder data class
    public static class Reminder {
        private String title;
        private String time;
        private boolean done;
        private boolean hasScan;

        public Reminder(String title, String time, boolean done) {
            this(title, time, done, false);
        }

        public Reminder(String title, String time, boolean done, boolean hasScan) {
            this.title = title;
            this.time = time;
            this.done = done;
            this.hasScan = hasScan;
        }

        public String getTitle() { return title; }
        public String getTime() { return time; }
        public boolean isDone() { return done; }
        public void setDone(boolean done) { this.done = done; }
        public boolean hasScan() { return hasScan; }
    }

    // RecyclerView Adapter
    private class ReminderAdapter extends RecyclerView.Adapter<ReminderAdapter.ViewHolder> {
        private List<Reminder> reminders = new ArrayList<>();

        class ViewHolder extends RecyclerView.ViewHolder {
            ImageView ivIcon;
            TextView tvTitle, tvTime;
            CheckBox cbStatus;
            Button btnScan;

            ViewHolder(View itemView) {
                super(itemView);
                ivIcon = itemView.findViewById(R.id.ivReminderIcon);
                tvTitle = itemView.findViewById(R.id.tvReminderTitle);
                tvTime = itemView.findViewById(R.id.tvReminderTime);
                cbStatus = itemView.findViewById(R.id.cbReminderStatus);
                btnScan = itemView.findViewById(R.id.btnScan);
            }
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_reminder, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            Reminder reminder = reminders.get(position);
            holder.tvTitle.setText(reminder.getTitle());
            holder.tvTime.setText(reminder.getTime());
            holder.cbStatus.setChecked(reminder.isDone());

            // Handle scan button visibility and click
            if (reminder.hasScan()) {
                holder.btnScan.setVisibility(View.VISIBLE);
                holder.btnScan.setOnClickListener(v -> {
                    Intent intent = new Intent(RemActivity.this, UploadReportActivity.class);
                    intent.putExtra("PATIENT_ID", patientId);
                    startActivity(intent);
                });
            } else {
                holder.btnScan.setVisibility(View.GONE);
            }

            holder.cbStatus.setOnCheckedChangeListener((buttonView, isChecked) -> {
                reminder.setDone(isChecked);
            });
        }

        @Override
        public int getItemCount() {
            return reminders.size();
        }

        public void updateReminders(List<Reminder> newReminders) {
            this.reminders = newReminders;
            notifyDataSetChanged();
        }
    }
}