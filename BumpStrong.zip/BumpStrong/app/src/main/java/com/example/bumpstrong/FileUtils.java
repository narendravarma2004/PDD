package com.example.bumpstrong;

import android.content.Context;
import android.net.Uri;
import java.io.File;

public class FileUtils {
    public static File getFileFromUri(Context context, Uri uri) {
        return new File(uri.getPath());
    }
}
