package com.example.bumpstrong;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class DoctorSignupActivity extends AppCompatActivity {

    private TextInputEditText etName, etUsername, etEmail, etPassword, etRePassword, etPhoneNumber, etSpecialization, etExperience;
    private Button btnSignup;
    private TextView tvLoginLink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_signup);

        // Initialize UI elements
        etName = findViewById(R.id.et_name);
        etUsername = findViewById(R.id.et_username);
        etEmail = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);
        etRePassword = findViewById(R.id.et_re_password);
        etPhoneNumber = findViewById(R.id.et_phonenumber);
        etSpecialization = findViewById(R.id.et_specialization);
        etExperience = findViewById(R.id.et_experience);
        btnSignup = findViewById(R.id.btn_signup);
        tvLoginLink = findViewById(R.id.tv_login_link);

        // Set click listener for signup button
        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signupDoctor();
            }
        });

        // Set click listener for login link
        tvLoginLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DoctorSignupActivity.this, DoctorLoginActivity.class));
            }
        });
    }

    private void signupDoctor() {
        // Get input values
        String name = etName.getText().toString().trim();
        String username = etUsername.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String rePassword = etRePassword.getText().toString().trim();
        String phoneNumber = etPhoneNumber.getText().toString().trim();
        String specialization = etSpecialization.getText().toString().trim();
        String experience = etExperience.getText().toString().trim();

        // Validate input fields
        if (name.isEmpty() || username.isEmpty() || email.isEmpty() || password.isEmpty() || rePassword.isEmpty() ||
                phoneNumber.isEmpty() || specialization.isEmpty() || experience.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!password.equals(rePassword)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return;
        }

        // Execute signup task in background
        new SignupTask().execute(name, username, email, password, phoneNumber, specialization, experience);
    }

    // AsyncTask to handle HTTP request
    private class SignupTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            String name = params[0];
            String username = params[1];
            String email = params[2];
            String password = params[3];
            String phoneNumber = params[4];
            String specialization = params[5];
            String experience = params[6];
            String urlString = "http://192.168.85.64/bumpstrong/doctorsignup.php"; // Replace with your local IP
            HttpURLConnection urlConnection = null;

            try {
                // Setup URL and connection
                URL url = new URL(urlString);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("POST");
                urlConnection.setDoOutput(true);
                urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                // Prepare POST data
                String postData = "name=" + name +
                        "&username=" + username +
                        "&email=" + email +
                        "&password=" + password +
                        "&phonenumber=" + phoneNumber +
                        "&specialization=" + specialization +
                        "&experience=" + experience;
                DataOutputStream outputStream = new DataOutputStream(urlConnection.getOutputStream());
                outputStream.writeBytes(postData);
                outputStream.flush();
                outputStream.close();

                // Get response
                BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();
                return response.toString();

            } catch (IOException e) {
                e.printStackTrace();
                return "Error: " + e.getMessage();
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
            }
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            // Handle response
            try {
                JSONObject jsonObject = new JSONObject(result);
                String status = jsonObject.getString("status");
                String message = jsonObject.getString("message");

                Toast.makeText(DoctorSignupActivity.this, message, Toast.LENGTH_SHORT).show();
                if (status.equals("success")) {
                    startActivity(new Intent(DoctorSignupActivity.this, DoctorLoginActivity.class));
                    finish();
                }
            } catch (JSONException e) {
                Toast.makeText(DoctorSignupActivity.this, "Error parsing response", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(DoctorSignupActivity.this, result, Toast.LENGTH_SHORT).show();
            }
        }
    }
}