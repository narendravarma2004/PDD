package com.example.bumpstrong;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;

public class PatientProfileActivity extends AppCompatActivity {

    private TextView tvPatientId, tvPatientName;
    private Button btnViewDetails, btnChangePassword, btnLogout;
    private ImageView btnBack, ivProfileImage;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_menu);

        // Initialize UI components
        tvPatientId = findViewById(R.id.tv_patient_id);
        tvPatientName = findViewById(R.id.tv_patient_name);
        ivProfileImage = findViewById(R.id.iv_profile_image);
        btnViewDetails = findViewById(R.id.btn_view_details);
        btnChangePassword = findViewById(R.id.btn_change_password);
        btnLogout = findViewById(R.id.btn_logout);
        btnBack = findViewById(R.id.btn_back);

        // Retrieve patient_id from SharedPreferences
        sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        String patientId = sharedPreferences.getString("patient_id", null);

        if (patientId != null) {
            fetchPatientDetails(patientId);
        } else {
            Toast.makeText(this, "Patient ID not found", Toast.LENGTH_LONG).show();
        }

        // Back button
        btnBack.setOnClickListener(v -> finish());

        // View Details Button
        btnViewDetails.setOnClickListener(v -> {
            Intent intent = new Intent(PatientProfileActivity.this, PatientDetailsShowActivity.class);
            startActivity(intent);
        });

        // Change Password Button
        btnChangePassword.setOnClickListener(v -> {
            Intent intent = new Intent(PatientProfileActivity.this, PatientHomeActivity.class);
            startActivity(intent);
        });

        // Logout button
        btnLogout.setOnClickListener(v -> {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.clear();
            editor.apply();
            Toast.makeText(PatientProfileActivity.this, "Logged Out", Toast.LENGTH_SHORT).show();

            // Go to MainActivity and clear back stack
            Intent intent = new Intent(PatientProfileActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish(); // Optional, but ensures current activity ends
        });
    }

    private void fetchPatientDetails(String patientId) {
        new Thread(() -> {
            try {
                String encodedPatientId = URLEncoder.encode(patientId, "UTF-8");
                URL url = new URL("http://192.168.85.64/bumpstrong/fetch_patient.php?patient_id=" + encodedPatientId);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                int responseCode = conn.getResponseCode();
                if (responseCode != HttpURLConnection.HTTP_OK) {
                    throw new Exception("Server returned response code: " + responseCode);
                }

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder result = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }
                reader.close();

                Log.d("PatientProfile", "Response from server: " + result.toString());

                JSONObject jsonObject = new JSONObject(result.toString());

                runOnUiThread(() -> updateUI(jsonObject));

            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(PatientProfileActivity.this, "Error fetching details", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private void updateUI(JSONObject jsonObject) {
        try {
            if (jsonObject.has("error")) {
                Toast.makeText(this, jsonObject.getString("error"), Toast.LENGTH_LONG).show();
                return;
            }

            JSONObject patient = jsonObject.getJSONObject("patient");

            tvPatientId.setText("Patient ID: " + patient.optString("patient_id", "N/A"));
            tvPatientName.setText("Name: " + patient.optString("firstName", "N/A") + " " + patient.optString("lastName", "N/A"));

        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error parsing data", Toast.LENGTH_SHORT).show();
        }
    }
}
