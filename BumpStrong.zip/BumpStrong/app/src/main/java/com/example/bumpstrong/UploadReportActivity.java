package com.example.bumpstrong;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textview.MaterialTextView;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class UploadReportActivity extends AppCompatActivity {
    private static final int PICK_FILE_REQUEST = 1;
    private static final String TAG = "UploadReportActivity";
    private static final String SERVER_URL = "http://192.168.85.64/bumpstrong/upload.php";
    private static final String FETCH_URL = "http://192.168.85.64/bumpstrong/fetch_patient.php";

    private Uri fileUri;
    private File copiedFile;
    private MaterialTextView txtFileName, txtPatientInfo;
    private TextInputEditText edtReportName;
    private MaterialButton btnUploadFile;
    private SharedPreferences sharedPreferences;
    private String patientId, patientName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_report);

        // Initialize UI components
        txtPatientInfo = findViewById(R.id.txtPatientInfo);
        edtReportName = findViewById(R.id.edtReportName);
        txtFileName = findViewById(R.id.txtFileName);
        MaterialButton btnSelectFile = findViewById(R.id.btnSelectFile);
        btnUploadFile = findViewById(R.id.btnUploadFile);

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        patientId = sharedPreferences.getString("patient_id", null);

        if (patientId != null) {
            fetchPatientDetails(patientId); // Fetch details from server
        } else {
            Toast.makeText(this, "Please log in to continue", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, PatientLoginActivity.class)); // Replace with your login activity
            finish();
            return;
        }

        // Button click listeners
        btnSelectFile.setOnClickListener(v -> selectFile());
        btnUploadFile.setOnClickListener(v -> uploadFile());
    }

    private void selectFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, PICK_FILE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE_REQUEST && resultCode == RESULT_OK && data != null) {
            fileUri = data.getData();
            if (fileUri != null) {
                copyFileToInternalStorage(fileUri);
            }
        }
    }

    private void copyFileToInternalStorage(Uri uri) {
        try {
            String fileName = getFileName(uri);
            File dir = getFilesDir();
            copiedFile = new File(dir, fileName);

            try (InputStream inputStream = getContentResolver().openInputStream(uri);
                 OutputStream outputStream = new FileOutputStream(copiedFile)) {
                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                }
            }

            txtFileName.setText(fileName);
            btnUploadFile.setVisibility(View.VISIBLE);
            Toast.makeText(this, "File selected: " + fileName, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e(TAG, "Error copying file: " + e.getMessage());
            Toast.makeText(this, "Failed to select file: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String getFileName(Uri uri) {
        String result = "unknown_file";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (nameIndex != -1) {
                    result = cursor.getString(nameIndex);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting file name: " + e.getMessage());
        }
        return result;
    }

    private void uploadFile() {
        String reportName = edtReportName.getText().toString().trim();
        if (reportName.isEmpty()) {
            edtReportName.setError("Please enter report name");
            return;
        }
        if (copiedFile == null || !copiedFile.exists()) {
            Toast.makeText(this, "Please select a file", Toast.LENGTH_SHORT).show();
            return;
        }
        if (patientId == null || patientName == null) {
            Toast.makeText(this, "Patient details not loaded", Toast.LENGTH_SHORT).show();
            return;
        }

        new Thread(() -> {
            String result = performFileUpload(copiedFile, reportName);
            runOnUiThread(() -> {
                Toast.makeText(this, result, Toast.LENGTH_LONG).show();
                if (result.contains("successfully")) {
                    resetForm();
                }
            });
        }).start();
    }

    private String performFileUpload(File file, String reportName) {
        try {
            RequestBody requestBody = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("patient_id", patientId)
                    .addFormDataPart("patient_name", patientName)
                    .addFormDataPart("report_name", reportName)
                    .addFormDataPart("file", file.getName(),
                            RequestBody.create(MediaType.parse("multipart/form-data"), file))
                    .build();

            Request request = new Request.Builder()
                    .url(SERVER_URL)
                    .post(requestBody)
                    .build();

            OkHttpClient client = new OkHttpClient();
            Response response = client.newCall(request).execute();

            if (response.isSuccessful()) {
                return response.body() != null ? response.body().string() : "Upload successful";
            } else {
                return "Upload failed: " + response.message();
            }
        } catch (Exception e) {
            Log.e(TAG, "Upload error: " + e.getMessage());
            return "Error uploading file: " + e.getMessage();
        }
    }

    private void fetchPatientDetails(String patientId) {
        new Thread(() -> {
            try {
                String encodedPatientId = URLEncoder.encode(patientId, "UTF-8");
                URL url = new URL(FETCH_URL + "?patient_id=" + encodedPatientId);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                int responseCode = conn.getResponseCode();
                if (responseCode != HttpURLConnection.HTTP_OK) {
                    throw new Exception("Server returned response code: " + responseCode);
                }

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder result = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }
                reader.close();

                Log.d(TAG, "Response from server: " + result.toString());
                JSONObject jsonObject = new JSONObject(result.toString());

                runOnUiThread(() -> updateUI(jsonObject));
            } catch (Exception e) {
                Log.e(TAG, "Error fetching patient details: " + e.getMessage());
                runOnUiThread(() -> Toast.makeText(this, "Error fetching patient details", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private void updateUI(JSONObject jsonObject) {
        try {
            if (jsonObject.has("error")) {
                Toast.makeText(this, jsonObject.getString("error"), Toast.LENGTH_LONG).show();
                return;
            }

            JSONObject patient = jsonObject.getJSONObject("patient");
            patientId = patient.optString("patient_id", "N/A");
            patientName = patient.optString("firstName", "N/A") + " " + patient.optString("lastName", "N/A");

            txtPatientInfo.setText("Patient: " + patientName + " (ID: " + patientId + ")");
        } catch (Exception e) {
            Log.e(TAG, "Error parsing patient data: " + e.getMessage());
            Toast.makeText(this, "Error parsing patient data", Toast.LENGTH_SHORT).show();
        }
    }

    private void resetForm() {
        edtReportName.setText("");
        txtFileName.setText("No file selected");
        btnUploadFile.setVisibility(View.GONE);
        copiedFile = null;
        fileUri = null;
    }
}