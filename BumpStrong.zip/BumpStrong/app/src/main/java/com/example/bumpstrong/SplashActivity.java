package com.example.bumpstrong;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "LoginPrefs";
    private static final String KEY_PATIENT_ID = "patient_id";
    private static final String KEY_DOCTOR_ID = "doctor_id";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Load the fade-in animation
        Animation fadeInAnimation = AnimationUtils.loadAnimation(this, R.anim.fade_in_logo);

        // Apply animation to the logo
        ImageView splashLogo = findViewById(R.id.splashLogo);
        splashLogo.startAnimation(fadeInAnimation);

        new Handler().postDelayed(() -> {
            SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            String patientId = sharedPreferences.getString(KEY_PATIENT_ID, null);
            String doctorId = sharedPreferences.getString(KEY_DOCTOR_ID, null);

            Intent intent;

            if (patientId != null && !patientId.isEmpty()) {
                // Patient is logged in
                intent = new Intent(SplashActivity.this, PatientHomeActivity.class);
                intent.putExtra("PATIENT_ID", patientId);
            } else if (doctorId != null && !doctorId.isEmpty()) {
                // Doctor is logged in
                intent = new Intent(SplashActivity.this, DoctorHomeActivity.class);
                intent.putExtra("DOCTOR_ID", doctorId);
            } else {
                // No one is logged in
                intent = new Intent(SplashActivity.this, MainActivity.class);
            }

            startActivity(intent);
            finish();
        }, 2000); // 2-second splash duration
    }
}
