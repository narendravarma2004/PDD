// DeliveryOutcomeActivity.java
package com.example.bumpstrong;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import org.json.JSONObject;

public class DeliveryOutcomeActivity extends AppCompatActivity {

    private Button btnNormalDelivery, btnCSection, btnDifficultyYes, btnDifficultyNo, btnSave;
    private String selectedMethod = "";
    private String selectedDifficulty = "";
    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "LoginPrefs";
    private static final String KEY_DELIVERY_METHOD = "delivery_method";
    private static final String KEY_DIFFICULTY = "difficulty";
    private static final String BASE_URL = "http://192.168.85.64/bumpstrong/deliveryoutcome.php";
    private static final String TAG = "DeliveryOutcomeActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_outcome);

        btnNormalDelivery = findViewById(R.id.btnNormalDelivery);
        btnCSection = findViewById(R.id.btnCSection);
        btnDifficultyYes = findViewById(R.id.btnDifficultyYes);
        btnDifficultyNo = findViewById(R.id.btnDifficultyNo);
        btnSave = findViewById(R.id.btnSave);

        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Load saved preferences if any (for UI only)
        selectedMethod = sharedPreferences.getString(KEY_DELIVERY_METHOD, "");
        selectedDifficulty = sharedPreferences.getString(KEY_DIFFICULTY, "");
        updateButtonSelection();

        btnNormalDelivery.setOnClickListener(v -> {
            selectedMethod = "Normal Vaginal Delivery";
            updateButtonSelection();
        });

        btnCSection.setOnClickListener(v -> {
            selectedMethod = "C-Section";
            updateButtonSelection();
        });

        btnDifficultyYes.setOnClickListener(v -> {
            selectedDifficulty = "Yes";
            updateButtonSelection();
        });

        btnDifficultyNo.setOnClickListener(v -> {
            selectedDifficulty = "No";
            updateButtonSelection();
        });

        btnSave.setOnClickListener(v -> {
            if (!selectedMethod.isEmpty() && !selectedDifficulty.isEmpty()) {
                String patientId = sharedPreferences.getString("patient_id", null);
                if (patientId != null) {
                    saveDeliveryOutcome(patientId, selectedMethod, selectedDifficulty);
                } else {
                    Toast.makeText(this, "Patient ID not found!", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Please select delivery method and difficulty!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateButtonSelection() {
        int selectedColor = ContextCompat.getColor(this, R.color.button_selected);
        int defaultColor = ContextCompat.getColor(this, R.color.button_normal);

        // Delivery Method Buttons
        if (selectedMethod.equals("Normal Vaginal Delivery")) {
            btnNormalDelivery.setBackgroundColor(selectedColor);
            btnCSection.setBackgroundColor(defaultColor);
        } else if (selectedMethod.equals("C-Section")) {
            btnNormalDelivery.setBackgroundColor(defaultColor);
            btnCSection.setBackgroundColor(selectedColor);
        } else {
            btnNormalDelivery.setBackgroundColor(defaultColor);
            btnCSection.setBackgroundColor(defaultColor);
        }

        // Difficulty Buttons
        if (selectedDifficulty.equals("Yes")) {
            btnDifficultyYes.setBackgroundColor(selectedColor);
            btnDifficultyNo.setBackgroundColor(defaultColor);
        } else if (selectedDifficulty.equals("No")) {
            btnDifficultyYes.setBackgroundColor(defaultColor);
            btnDifficultyNo.setBackgroundColor(selectedColor);
        } else {
            btnDifficultyYes.setBackgroundColor(defaultColor);
            btnDifficultyNo.setBackgroundColor(defaultColor);
        }
    }

    private void saveDeliveryOutcome(String patientId, String deliveryMethod, String difficulty) {
        new Thread(() -> {
            try {
                URL url = new URL(BASE_URL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);

                // Prepare POST data with URLEncoder
                String postData = "patient_id=" + URLEncoder.encode(patientId, "UTF-8") +
                        "&delivery_method=" + URLEncoder.encode(deliveryMethod, "UTF-8") +
                        "&difficulty=" + URLEncoder.encode(difficulty, "UTF-8");
                OutputStream os = conn.getOutputStream();
                os.write(postData.getBytes("UTF-8"));
                os.flush();
                os.close();

                // Get response
                int responseCode = conn.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();

                    JSONObject jsonResponse = new JSONObject(response.toString());
                    String status = jsonResponse.getString("status");
                    String message = jsonResponse.getString("message");

                    // Handle response on UI thread
                    new Handler(Looper.getMainLooper()).post(() -> {
                        if ("success".equals(status)) {
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putString(KEY_DELIVERY_METHOD, deliveryMethod);
                            editor.putString(KEY_DIFFICULTY, difficulty);
                            editor.apply();
                            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                            navigateToSideBar();
                        } else {
                            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                        }
                    });
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "Server error: " + responseCode, Toast.LENGTH_SHORT).show());
                }
                conn.disconnect();
            } catch (Exception e) {
                Log.e(TAG, "Error saving delivery outcome", e);
                runOnUiThread(() -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private void navigateToSideBar() {
        Intent intent = new Intent(DeliveryOutcomeActivity.this, PatientHomeActivity.class);
        startActivity(intent);
        finish();
    }
}