package com.example.bumpstrong;

public class Video {
    private String title;
    private String videoPath;
    private String thumbnailPath;

    public Video(String title, String videoPath, String thumbnailPath) {
        this.title = title;
        this.videoPath = videoPath;
        this.thumbnailPath = thumbnailPath;
    }

    public String getTitle() {
        return title;
    }

    public String getVideoPath() {
        return videoPath;
    }

    public String getThumbnailPath() {
        return thumbnailPath;
    }
}
