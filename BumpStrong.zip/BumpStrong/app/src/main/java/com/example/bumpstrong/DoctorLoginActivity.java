package com.example.bumpstrong;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class DoctorLoginActivity extends AppCompatActivity {

    private static final String TAG = "DoctorLoginActivity";

    private static final String PREFS_NAME = "LoginPrefs";
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";
    private static final String KEY_DOCTOR_ID = "doctor_id";

    private TextInputEditText etUsername, etPassword;
    private Button btnLogin;
    private TextView tvSignupLink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_login);

        etUsername = findViewById(R.id.et_username);
        etPassword = findViewById(R.id.et_password);
        btnLogin = findViewById(R.id.btn_login);
        tvSignupLink = findViewById(R.id.tv_signup_link);

        btnLogin.setOnClickListener(v -> loginDoctor());

        tvSignupLink.setOnClickListener(v -> {
            Intent intent = new Intent(DoctorLoginActivity.this, DoctorSignupActivity.class);
            startActivity(intent);
        });
    }

    private void loginDoctor() {
        String username = etUsername.getText() != null ? etUsername.getText().toString().trim() : "";
        String password = etPassword.getText() != null ? etPassword.getText().toString().trim() : "";

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        new LoginTask().execute(username, password);
    }

    private class LoginTask extends AsyncTask<String, Void, String> {

        private String username;

        @Override
        protected String doInBackground(String... params) {
            username = params[0];
            String password = params[1];
            String urlString = "http://192.168.85.64/bumpstrong/doctorlogin.php";

            try {
                URL url = new URL(urlString);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                JSONObject json = new JSONObject();
                json.put("username", username);
                json.put("password", password);

                try (DataOutputStream os = new DataOutputStream(conn.getOutputStream())) {
                    os.writeBytes(json.toString());
                    os.flush();
                }

                int responseCode = conn.getResponseCode();
                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        responseCode >= 200 && responseCode < 300 ? conn.getInputStream() : conn.getErrorStream()
                ));

                StringBuilder result = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }

                reader.close();
                conn.disconnect();
                return result.toString();

            } catch (IOException | JSONException e) {
                Log.e(TAG, "Network Error: ", e);
                return "{\"status\":\"error\",\"message\":\"Network Error\"}";
            }
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                JSONObject json = new JSONObject(result);
                String status = json.optString("status", "error");
                String message = json.optString("message", "Unexpected error");

                Toast.makeText(DoctorLoginActivity.this, message, Toast.LENGTH_SHORT).show();

                if (status.equalsIgnoreCase("success")) {
                    SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                    prefs.edit()
                            .putBoolean(KEY_IS_LOGGED_IN, true)
                            .putString(KEY_DOCTOR_ID, username)
                            .apply();

                    Intent intent = new Intent(DoctorLoginActivity.this, DoctorHomeActivity.class);
                    intent.putExtra(KEY_DOCTOR_ID, username);
                    startActivity(intent);
                    finish();
                }

            } catch (JSONException e) {
                Log.e(TAG, "Parsing error: " + e.getMessage(), e);
                Toast.makeText(DoctorLoginActivity.this, "Response parsing error", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
