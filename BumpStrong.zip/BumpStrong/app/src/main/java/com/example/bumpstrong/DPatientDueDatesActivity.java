package com.example.bumpstrong;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class DPatientDueDatesActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private DueDateAdapter dueDateAdapter;
    private List<PatientDueDate> patientDueDates;
    private static final String TAG = "DPatientDueDatesActivity";
    private static final String FETCH_URL = "http://192.168.85.64/bumpstrong/fetch_due_dates.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_patient_duedate); // Corrected layout name

        recyclerView = findViewById(R.id.recyclerViewDueDates);
        patientDueDates = new ArrayList<>();

        // Set up RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        dueDateAdapter = new DueDateAdapter(patientDueDates);
        recyclerView.setAdapter(dueDateAdapter);

        // Fetch due dates
        fetchDueDates();
    }

    private void fetchDueDates() {
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(FETCH_URL);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                int responseCode = conn.getResponseCode();
                Log.d(TAG, "Server response code: " + responseCode);

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder result = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        result.append(line);
                    }
                    reader.close();

                    String rawResponse = result.toString();
                    Log.d(TAG, "Raw response from server: " + rawResponse);

                    JSONArray jsonArray = new JSONArray(rawResponse);
                    List<PatientDueDate> fetchedDueDates = new ArrayList<>();

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject patient = jsonArray.getJSONObject(i);
                        String fullName = patient.optString("firstName", "N/A") + " " + patient.optString("lastName", "N/A");
                        String dueDate = patient.optString("dueDate", "N/A");
                        fetchedDueDates.add(new PatientDueDate(fullName, dueDate));
                    }

                    runOnUiThread(() -> {
                        patientDueDates.clear();
                        patientDueDates.addAll(fetchedDueDates);
                        dueDateAdapter.notifyDataSetChanged();
                        if (patientDueDates.isEmpty()) {
                            Toast.makeText(this, "No due dates found", Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    String errorMsg = "Server error: " + responseCode;
                    if (responseCode == 404) {
                        errorMsg = "Server error: Resource not found (404). Check URL: " + FETCH_URL;
                    }
                    final String finalErrorMsg = errorMsg;
                    runOnUiThread(() -> Toast.makeText(this, finalErrorMsg, Toast.LENGTH_LONG).show());
                    Log.e(TAG, errorMsg);
                }
            } catch (Exception e) {
                Log.e(TAG, "Error fetching due dates: " + e.getMessage(), e);
                runOnUiThread(() -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show());
            } finally {
                if (conn != null) {
                    conn.disconnect();
                }
            }
        }).start();
    }

    // Data class for patient name and due date
    private static class PatientDueDate {
        String name;
        String dueDate;

        PatientDueDate(String name, String dueDate) {
            this.name = name;
            this.dueDate = dueDate;
        }
    }

    // RecyclerView Adapter
    private static class DueDateAdapter extends RecyclerView.Adapter<DueDateAdapter.ViewHolder> {
        private final List<PatientDueDate> patientDueDates;

        DueDateAdapter(List<PatientDueDate> patientDueDates) {
            this.patientDueDates = patientDueDates;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_due_date, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            PatientDueDate patientDueDate = patientDueDates.get(position);
            holder.tvPatientName.setText(patientDueDate.name);
            holder.tvDueDate.setText("Due: " + patientDueDate.dueDate);
        }

        @Override
        public int getItemCount() {
            return patientDueDates.size();
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvPatientName, tvDueDate;

            ViewHolder(View itemView) {
                super(itemView);
                tvPatientName = itemView.findViewById(R.id.tvPatientName);
                tvDueDate = itemView.findViewById(R.id.tvDueDate);
            }
        }
    }
}