package com.example.bumpstrong;
import androidx.core.content.FileProvider;


import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textview.MaterialTextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class DReportDetailsActivity extends AppCompatActivity {
    private static final String TAG = "DReportDetailsActivity";
    private static final String FETCH_REPORTS_URL = "http://192.168.85.64/bumpstrong/fetch_patient_reports.php"; // For physical device
    // private static final String FETCH_REPORTS_URL = "http://10.0.2.2:8080/bumpstrong/fetch_patient_reports.php"; // Uncomment for emulator
    private static final String BASE_URL = "http://192.168.85.64/bumpstrong/"; // Base URL for file paths (physical device)
    // private static final String BASE_URL = "http://10.0.2.2:8080/bumpstrong/"; // Uncomment for emulator
    private RecyclerView rvReports;
    private ReportAdapter reportAdapter;
    private List<Report> reportList;
    private MaterialTextView txtPatientInfo;
    private String patientId, patientName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_report_details);

        rvReports = findViewById(R.id.rvReports);
        txtPatientInfo = findViewById(R.id.txtPatientInfo);
        MaterialButton btnBack = findViewById(R.id.btnBack);

        patientId = getIntent().getStringExtra("patient_id");
        patientName = getIntent().getStringExtra("patient_name");

        txtPatientInfo.setText("Patient: " + patientName + " (ID: " + patientId + ")");

        reportList = new ArrayList<>();
        reportAdapter = new ReportAdapter(reportList);
        rvReports.setLayoutManager(new LinearLayoutManager(this));
        rvReports.setAdapter(reportAdapter);

        fetchPatientReports(patientId);

        btnBack.setOnClickListener(v -> finish());
    }

    private void fetchPatientReports(String patientId) {
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                String urlString = FETCH_REPORTS_URL + "?patient_id=" + patientId;
                Log.d(TAG, "Fetching reports from: " + urlString);
                URL url = new URL(urlString);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                int responseCode = conn.getResponseCode();
                Log.d(TAG, "Response code: " + responseCode);
                if (responseCode != HttpURLConnection.HTTP_OK) {
                    throw new Exception("Server returned response code: " + responseCode);
                }

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder result = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }
                reader.close();

                Log.d(TAG, "Response from server: " + result.toString());
                JSONArray jsonArray = new JSONArray(result.toString());

                reportList.clear();
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject report = jsonArray.getJSONObject(i);
                    reportList.add(new Report(
                            report.getString("report_name"),
                            report.getString("file_name"),
                            report.getString("file_path")
                    ));
                }

                runOnUiThread(() -> reportAdapter.notifyDataSetChanged());
            } catch (Exception e) {
                Log.e(TAG, "Error fetching reports: " + e.getMessage());
                runOnUiThread(() -> Toast.makeText(this, "Error fetching reports: " + e.getMessage(), Toast.LENGTH_LONG).show());
            } finally {
                if (conn != null) {
                    conn.disconnect();
                }
            }
        }).start();
    }

    private void downloadAndViewFile(String filePath, String fileName) {
        new Thread(() -> {
            try {
                // Construct full URL for the file
                String fullUrl = filePath.startsWith("http") ? filePath : BASE_URL + filePath;
                Log.d(TAG, "Downloading file from: " + fullUrl);
                OkHttpClient client = new OkHttpClient();
                Request request = new Request.Builder()
                        .url(fullUrl)
                        .build();
                Response response = client.newCall(request).execute();

                if (!response.isSuccessful()) {
                    throw new Exception("Failed to download file: " + response.message() + " (Code: " + response.code() + ")");
                }

                // Save file to temporary storage
                File tempFile = new File(getCacheDir(), fileName);
                Log.d(TAG, "Saving file to: " + tempFile.getAbsolutePath());
                try (InputStream inputStream = response.body().byteStream();
                     FileOutputStream outputStream = new FileOutputStream(tempFile)) {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    long totalBytes = 0;
                    while ((bytesRead = inputStream.read(buffer)) != -1) {
                        outputStream.write(buffer, 0, bytesRead);
                        totalBytes += bytesRead;
                    }
                    Log.d(TAG, "File downloaded successfully, size: " + totalBytes + " bytes");
                }

                runOnUiThread(() -> displayFile(tempFile, fileName));
            } catch (Exception e) {
                Log.e(TAG, "Error downloading file: " + e.getMessage());
                runOnUiThread(() -> Toast.makeText(this, "Error downloading file: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void displayFile(File file, String fileName) {
        if (!file.exists() || file.length() == 0) {
            Toast.makeText(this, "File is empty or not downloaded", Toast.LENGTH_LONG).show();
            return;
        }

        String extension = fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();
        Log.d(TAG, "Displaying file: " + fileName + " (Extension: " + extension + ")");

        if (extension.equals("jpg") || extension.equals("jpeg") || extension.equals("png")) {
            Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
            if (bitmap != null) {
                ImageView imageView = new ImageView(this);
                imageView.setImageBitmap(bitmap);
                new AlertDialog.Builder(this)
                        .setTitle(fileName)
                        .setView(imageView)
                        .setPositiveButton("Close", (dialog, which) -> dialog.dismiss())
                        .show();
            } else {
                Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show();
            }
        } else {
            Uri fileUri = FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".fileprovider", file);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(fileUri, getMimeType(extension));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            try {
                startActivity(intent);
            } catch (Exception e) {
                Log.e(TAG, "Error opening file: " + e.getMessage());
                Toast.makeText(this, "No app available to open this file type", Toast.LENGTH_LONG).show();
            }
        }
    }


    private String getMimeType(String extension) {
        switch (extension) {
            case "pdf":
                return "application/pdf";
            case "jpg":
            case "jpeg":
                return "image/jpeg";
            case "png":
                return "image/png";
            default:
                return "*/*";
        }
    }

    private static class Report {
        String reportName, fileName, filePath;

        Report(String reportName, String fileName, String filePath) {
            this.reportName = reportName;
            this.fileName = fileName;
            this.filePath = filePath;
        }
    }

    private class ReportAdapter extends RecyclerView.Adapter<ReportAdapter.ReportViewHolder> {
        private final List<Report> reports;

        ReportAdapter(List<Report> reports) {
            this.reports = reports;
        }

        @Override
        public ReportViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(android.R.layout.simple_list_item_2, parent, false);
            return new ReportViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ReportViewHolder holder, int position) {
            Report report = reports.get(position);
            holder.text1.setText("Report: " + report.reportName);
            holder.text2.setText("File: " + report.fileName);
            holder.text2.setOnClickListener(v -> downloadAndViewFile(report.filePath, report.fileName));
        }

        @Override
        public int getItemCount() {
            return reports.size();
        }

        class ReportViewHolder extends RecyclerView.ViewHolder {
            MaterialTextView text1, text2;

            ReportViewHolder(View itemView) {
                super(itemView);
                text1 = itemView.findViewById(android.R.id.text1);
                text2 = itemView.findViewById(android.R.id.text2);
            }
        }
    }
}