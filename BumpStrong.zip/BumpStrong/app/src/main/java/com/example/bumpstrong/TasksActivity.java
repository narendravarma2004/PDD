package com.example.bumpstrong;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TasksActivity extends AppCompatActivity {
    private TextView tvPatientId, tvWeeks;
    private LinearLayout taskContainer;
    private Button btnRefresh;
    private SharedPreferences prefs, taskPrefs;
    private String patientId;
    private static final String PREFS_NAME = "LoginPrefs";
    private static final String PATIENT_ID_KEY = "patient_id";
    private static final String TASK_PREFS = "TaskPrefs";
    private static final String BASE_URL = "http://192.168.85.64/bumpstrong/fetch_date.php?patient_id=";
    private static final String TAG = "TaskActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tasks);

        tvPatientId = findViewById(R.id.tvPatientId);
        tvWeeks = findViewById(R.id.tvWeeks);
        taskContainer = findViewById(R.id.taskContainer);
        btnRefresh = findViewById(R.id.btnRefresh);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        taskPrefs = getSharedPreferences(TASK_PREFS, MODE_PRIVATE);

        patientId = getIntent().getStringExtra("PATIENT_ID");
        if (patientId == null || patientId.trim().isEmpty()) {
            patientId = prefs.getString(PATIENT_ID_KEY, "");
        }

        if (patientId == null || patientId.trim().isEmpty()) {
            Log.e(TAG, "No patientId found");
            tvPatientId.setText("Error: No Patient ID");
            return;
        }

        tvPatientId.setText("Patient ID: " + patientId);
        fetchPregnancyData(patientId);

        btnRefresh.setOnClickListener(v -> {
            taskContainer.removeAllViews();
            fetchPregnancyData(patientId);
        });
    }

    private void fetchPregnancyData(String patientId) {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL(BASE_URL + patientId);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();
                conn.disconnect();

                JSONObject json = new JSONObject(response.toString());
                String lmpDateStr = json.getJSONObject("patient").getString("lmpDate");
                runOnUiThread(() -> calculateAndDisplayTasks(lmpDateStr));
            } catch (Exception e) {
                Log.e(TAG, "Error fetching data: " + e.getMessage());
                runOnUiThread(() -> tvWeeks.setText("Error fetching data"));
            }
        });
    }

    private void calculateAndDisplayTasks(String lmpDateStr) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date lmpDate = sdf.parse(lmpDateStr);
            Date currentDate = new Date();

            long diffInMillies = currentDate.getTime() - lmpDate.getTime();
            int weeks = (int) (diffInMillies / (1000 * 60 * 60 * 24 * 7));
            tvWeeks.setText("Weeks Pregnant: " + weeks);

            displayDailyTasks(weeks);
        } catch (Exception e) {
            Log.e(TAG, "Error calculating weeks: " + e.getMessage());
            tvWeeks.setText("Error calculating weeks");
        }
    }

    private void displayDailyTasks(int weeks) {
        SharedPreferences.Editor editor = taskPrefs.edit();
        String today = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

        List<String> tasks = getTasksForWeeks(weeks);
        List<String> pendingTasks = new ArrayList<>(tasks);

        for (String task : tasks) {
            String taskKey = today + "_" + patientId + "_" + task.hashCode();
            if (!taskPrefs.getBoolean(taskKey, false)) {
                LinearLayout taskLayout = new LinearLayout(this);
                taskLayout.setOrientation(LinearLayout.HORIZONTAL);
                taskLayout.setPadding(8, 8, 8, 8);

                TextView taskText = new TextView(this);
                taskText.setText(task);
                taskText.setTextSize(16);
                taskText.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

                Button doneButton = new Button(this);
                doneButton.setText("Done");
                doneButton.setOnClickListener(v -> {
                    editor.putBoolean(taskKey, true).apply();
                    taskContainer.removeView(taskLayout);
                    pendingTasks.remove(task);
                    if (pendingTasks.isEmpty()) {
                        markDayAsCompleted(today);
                    }
                });

                taskLayout.addView(taskText);
                taskLayout.addView(doneButton);
                taskContainer.addView(taskLayout);
            }
        }
    }

    private void markDayAsCompleted(String date) {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                URL url = new URL("http://192.168.85.64/bumpstrong/update_progress.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                String postData = "patient_id=" + patientId + "&task_date=" + date;
                conn.getOutputStream().write(postData.getBytes());
                conn.disconnect();
            } catch (Exception e) {
                Log.e(TAG, "Error updating progress: " + e.getMessage());
            }
        });
    }

    private List<String> getTasksForWeeks(int weeks) {
        List<String> tasks = new ArrayList<>();
        if (weeks < 12) {
            tasks.add("Take prenatal vitamins");
            tasks.add("Drink 8-10 glasses of water");
            tasks.add("Rest for 30 minutes");
            tasks.add("Eat a healthy snack");
        } else if (weeks < 28) {
            tasks.add("Do 15 minutes of light exercise");
            tasks.add("Eat iron-rich foods");
            tasks.add("Monitor fetal movements");
            tasks.add("Practice relaxation techniques");
        } else {
            tasks.add("Practice breathing exercises");
            tasks.add("Walk for 20 minutes");
            tasks.add("Check hospital bag checklist");
            tasks.add("Rest with feet elevated");
        }
        return tasks;
    }
}
