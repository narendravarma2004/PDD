package com.example.bumpstrong;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
public class DoctorTaskAdapter extends RecyclerView.Adapter<DoctorTaskAdapter.TaskViewHolder> {
    private List<String> tasks;
    private OnTaskDoneListener listener;

    public interface OnTaskDoneListener {
        void onTaskDone(String task);
    }

    public DoctorTaskAdapter(List<String> tasks, OnTaskDoneListener listener) {
        this.tasks = tasks;
        this.listener = listener;
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_doctor_task, parent, false);
        return new TaskViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        String task = tasks.get(position);
        holder.tvTask.setText(task);
        holder.btnDone.setOnClickListener(v -> listener.onTaskDone(task));
    }

    @Override
    public int getItemCount() {
        return tasks.size();
    }

    static class TaskViewHolder extends RecyclerView.ViewHolder {
        TextView tvTask;
        Button btnDone;

        TaskViewHolder(View itemView) {
            super(itemView);
            tvTask = itemView.findViewById(R.id.tvTask);
            btnDone = itemView.findViewById(R.id.btnDone);
        }
    }
}