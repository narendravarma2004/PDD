package com.example.bumpstrong;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ReminderAdapter extends RecyclerView.Adapter<ReminderAdapter.ViewHolder> {
    private List<RemActivity.Reminder> reminders;
    private SharedPreferences sharedPreferences;
    private Context context;
    private Runnable onAllCompleted;

    public ReminderAdapter(List<RemActivity.Reminder> reminders, SharedPreferences sharedPreferences,
                           Context context, Runnable onAllCompleted) {
        this.reminders = reminders;
        this.sharedPreferences = sharedPreferences;
        this.context = context;
        this.onAllCompleted = onAllCompleted;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.reminder_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        RemActivity.Reminder reminder = reminders.get(position);
        holder.reminderText.setText(reminder.getTitle());  // Changed from getText() to getTitle()
        holder.checkBox.setChecked(reminder.isDone());

        holder.checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            reminder.setDone(isChecked);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("reminder_done_" + position, isChecked);
            editor.apply();

            boolean allCompleted = true;
            for (RemActivity.Reminder r : reminders) {
                if (!r.isDone()) {
                    allCompleted = false;
                    break;
                }
            }

            if (allCompleted) {
                onAllCompleted.run();
            }
        });
    }

    @Override
    public int getItemCount() {
        return reminders.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView reminderText;
        CheckBox checkBox;

        public ViewHolder(View itemView) {
            super(itemView);
            reminderText = itemView.findViewById(R.id.reminderText);
            checkBox = itemView.findViewById(R.id.checkBox);
        }
    }
}