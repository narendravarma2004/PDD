// TaskAdapter.java
package com.example.bumpstrong;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {

    private List<String> tasks;
    private SharedPreferences sharedPreferences;
    private Context context;
    private OnAllTasksCompletedListener listener;

    public interface OnAllTasksCompletedListener {
        void onAllTasksCompleted();
    }

    public TaskAdapter(List<String> tasks, SharedPreferences sharedPreferences, Context context, OnAllTasksCompletedListener listener) {
        this.tasks = tasks;
        this.sharedPreferences = sharedPreferences;
        this.context = context;
        this.listener = listener;
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_task, parent, false);
        return new TaskViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        String task = tasks.get(position);
        holder.tvTask.setText(task);

        holder.itemView.setOnClickListener(v -> {
            int adapterPosition = holder.getAdapterPosition();
            if (adapterPosition != RecyclerView.NO_POSITION) {
                tasks.remove(adapterPosition);
                updateStoredTasks();
                notifyItemRemoved(adapterPosition);
                notifyItemRangeChanged(adapterPosition, tasks.size());

                if (tasks.isEmpty()) {
                    listener.onAllTasksCompleted();
                }
            }
        });
    }

    private void updateStoredTasks() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Set<String> updatedTasks = new HashSet<>(tasks);
        editor.putStringSet("today_tasks", updatedTasks);
        editor.apply();
    }


    @Override
    public int getItemCount() {
        return tasks.size();
    }

    public static class TaskViewHolder extends RecyclerView.ViewHolder {
        TextView tvTask;

        public TaskViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTask = itemView.findViewById(R.id.tvTask);
        }
    }
}