package com.example.bumpstrong;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class VideosRecommendationActivity extends AppCompatActivity {
    private RecyclerView videoRecyclerView;
    private String videoURL = "http://192.168.85.64/bumpstrong/fetch_videos.php";
    private ArrayList<VideoItem> videoList = new ArrayList<>();
    private static final String TAG = "VideosRecommendation";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_videos_recommendation);

        videoRecyclerView = findViewById(R.id.videoRecyclerView);
        if (videoRecyclerView == null) {
            Log.e(TAG, "RecyclerView not found in layout");
            Toast.makeText(this, "Error: RecyclerView not found", Toast.LENGTH_LONG).show();
            return;
        }

        videoRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        new FetchVideoTask().execute();
    }

    private class FetchVideoTask extends AsyncTask<Void, Void, String> {
        private ProgressDialog progressDialog = new ProgressDialog(VideosRecommendationActivity.this);

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setMessage("Loading recommended videos...");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }

        @Override
        protected String doInBackground(Void... voids) {
            try {
                URL url = new URL(videoURL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                InputStream inputStream = conn.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder result = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }
                reader.close();
                conn.disconnect();
                return result.toString();
            } catch (Exception e) {
                Log.e(TAG, "Error fetching videos: " + e.getMessage());
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            if (progressDialog.isShowing()) {
                progressDialog.dismiss();
            }
            if (result != null && !result.isEmpty()) {
                try {
                    JSONArray jsonArray = new JSONArray(result);
                    if (jsonArray.length() > 0) {
                        videoList.clear();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject videoObject = jsonArray.getJSONObject(i);
                            videoList.add(new VideoItem(
                                    videoObject.getString("video_name"),
                                    videoObject.getString("video_path"),
                                    videoObject.getString("thumbnail_path")));
                        }
                        VideoAdapter adapter = new VideoAdapter(VideosRecommendationActivity.this, videoList);
                        videoRecyclerView.setAdapter(adapter);
                    } else {
                        Toast.makeText(VideosRecommendationActivity.this, "No videos found", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    Log.e(TAG, "JSON parsing error: " + e.getMessage());
                    Toast.makeText(VideosRecommendationActivity.this, "Error parsing video data", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(VideosRecommendationActivity.this, "Failed to fetch videos - check network or server", Toast.LENGTH_LONG).show();
            }
        }
    }
}