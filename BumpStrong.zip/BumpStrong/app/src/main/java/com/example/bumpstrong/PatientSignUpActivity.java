package com.example.bumpstrong;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class PatientSignUpActivity extends AppCompatActivity {

    private EditText etUsername, etPassword, etMobile;
    private Button btnSignup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_signup);

        etUsername = findViewById(R.id.et_username);
        etPassword = findViewById(R.id.et_password);
        etMobile = findViewById(R.id.et_mobile);
        btnSignup = findViewById(R.id.btn_signup);

        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerPatient();
            }
        });
    }

    private void registerPatient() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String mobile = etMobile.getText().toString().trim();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password) || TextUtils.isEmpty(mobile)) {
            Toast.makeText(this, "All fields are required!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (mobile.length() != 10) {
            Toast.makeText(this, "Enter a valid 10-digit mobile number!", Toast.LENGTH_SHORT).show();
            return;
        }

        new RegisterPatientTask().execute(username, password, mobile);
    }

    private class RegisterPatientTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            try {
                String apiUrl = "http://192.168.85.64/bumpstrong/signup.php";
                URL url = new URL(apiUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setDoInput(true);
                conn.setRequestProperty("Content-Type", "application/json");

                // Create JSON object
                JSONObject postData = new JSONObject();
                postData.put("username", params[0]);
                postData.put("password", params[1]);
                postData.put("phonenumber", params[2]);

                // Send JSON data
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream(), "UTF-8"));
                writer.write(postData.toString());
                writer.flush();
                writer.close();

                // Read response
                InputStream inputStream = conn.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();
                inputStream.close();
                conn.disconnect();

                return response.toString();

            } catch (Exception e) {
                e.printStackTrace();
                return "{\"message\":\"Error: " + e.getMessage() + "\"}";
            }
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                JSONObject jsonResponse = new JSONObject(result);
                String message = jsonResponse.getString("message");

                if (jsonResponse.has("patient_id")) {
                    String patientId = jsonResponse.getString("patient_id");
                    Toast.makeText(PatientSignUpActivity.this, "Signup Successful! Patient ID: " + patientId, Toast.LENGTH_LONG).show();

                    // Navigate to the home activity
                    Intent intent = new Intent(PatientSignUpActivity.this, PatientHomeActivity.class);
                    intent.putExtra("patient_id", patientId); // Pass the patient ID
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(PatientSignUpActivity.this, "Signup Failed: " + message, Toast.LENGTH_LONG).show();
                }

            } catch (JSONException e) {
                e.printStackTrace();
                Toast.makeText(PatientSignUpActivity.this, "Error parsing server response", Toast.LENGTH_LONG).show();
            }
        }
    }
}
