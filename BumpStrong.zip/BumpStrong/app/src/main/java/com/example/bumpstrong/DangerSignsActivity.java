package com.example.bumpstrong;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class DangerSignsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private DangerSignsAdapter adapter;
    private List<DangerSign> dangerSigns;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dangersign);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        dangerSigns = new ArrayList<>();
        dangerSigns.add(new DangerSign(R.drawable.danger1, "Excessive Bleeding"));
        dangerSigns.add(new DangerSign(R.drawable.danger2, "High Fever"));
        dangerSigns.add(new DangerSign(R.drawable.danger3, "Severe Headache"));
        dangerSigns.add(new DangerSign(R.drawable.danger4, "Convulsions"));
        dangerSigns.add(new DangerSign(R.drawable.danger5, "Severe Abdominal Pain"));
        dangerSigns.add(new DangerSign(R.drawable.danger6, "Difficulty in Breathing"));

        adapter = new DangerSignsAdapter(this, dangerSigns);
        recyclerView.setAdapter(adapter);
    }
}
