package com.example.bumpstrong;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class DPatientListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private PatientAdapter patientAdapter;
    private List<String> patientNames;
    private static final String TAG = "DPatientListActivity";
    private static final String FETCH_URL = "http://192.168.85.64/bumpstrong/fetch_all_patients.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_patient_list);

        recyclerView = findViewById(R.id.recyclerViewPatients);
        patientNames = new ArrayList<>();

        // Set up RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        patientAdapter = new PatientAdapter(patientNames);
        recyclerView.setAdapter(patientAdapter);

        // Fetch patient data
        fetchAllPatients();
    }

    private void fetchAllPatients() {
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(FETCH_URL);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                int responseCode = conn.getResponseCode();
                Log.d(TAG, "Server response code: " + responseCode);

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder result = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        result.append(line);
                    }
                    reader.close();

                    String rawResponse = result.toString();
                    Log.d(TAG, "Raw response from server: " + rawResponse);

                    // Try parsing as JSONArray first
                    try {
                        JSONArray jsonArray = new JSONArray(rawResponse);
                        List<String> fetchedNames = new ArrayList<>();

                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject patient = jsonArray.getJSONObject(i);
                            String fullName = patient.optString("firstName", "N/A") + " " + patient.optString("lastName", "N/A");
                            fetchedNames.add(fullName);
                        }

                        runOnUiThread(() -> {
                            patientNames.clear();
                            patientNames.addAll(fetchedNames);
                            patientAdapter.notifyDataSetChanged();
                            if (patientNames.isEmpty()) {
                                Toast.makeText(this, "No patients found", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } catch (JSONException e) {
                        // If JSONArray fails, try JSONObject for error handling
                        Log.e(TAG, "Failed to parse as JSONArray, trying JSONObject: " + e.getMessage());
                        JSONObject jsonResponse = new JSONObject(rawResponse);
                        if (jsonResponse.has("error")) {
                            String errorMsg = jsonResponse.getString("error");
                            runOnUiThread(() -> Toast.makeText(this, "Server error: " + errorMsg, Toast.LENGTH_LONG).show());
                        } else {
                            throw e; // Re-throw if no error key
                        }
                    }
                } else {
                    String errorMsg = "Server error: " + responseCode;
                    if (responseCode == 404) {
                        errorMsg = "Server error: Resource not found (404). Check URL: " + FETCH_URL;
                    }
                    final String finalErrorMsg = errorMsg;
                    runOnUiThread(() -> Toast.makeText(this, finalErrorMsg, Toast.LENGTH_LONG).show());
                    Log.e(TAG, errorMsg);
                }

            } catch (Exception e) {
                Log.e(TAG, "Error fetching patient list: " + e.getMessage(), e);
                runOnUiThread(() -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show());
            } finally {
                if (conn != null) {
                    conn.disconnect();
                }
            }
        }).start();
    }

    // RecyclerView Adapter
    private class PatientAdapter extends RecyclerView.Adapter<PatientAdapter.ViewHolder> {
        private final List<String> patientNames;

        PatientAdapter(List<String> patientNames) {
            this.patientNames = patientNames;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_patient, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            String patientName = patientNames.get(position);
            holder.tvPatientName.setText(patientName);
            holder.itemView.setOnClickListener(v -> {
                Intent intent = new Intent(DPatientListActivity.this, DPatientDetailsActivity.class);
                intent.putExtra("PATIENT_NAME", patientName);
                startActivity(intent);
            });
        }

        @Override
        public int getItemCount() {
            return patientNames.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvPatientName;

            ViewHolder(View itemView) {
                super(itemView);
                tvPatientName = itemView.findViewById(R.id.tvPatientName);
            }
        }
    }
}