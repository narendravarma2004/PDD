package com.example.bumpstrong;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class DangerSignsAdapter extends RecyclerView.Adapter<DangerSignsAdapter.ViewHolder> {

    private Context context;
    private List<DangerSign> dangerSigns;

    public DangerSignsAdapter(Context context, List<DangerSign> dangerSigns) {
        this.context = context;
        this.dangerSigns = dangerSigns;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_danger_sign, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DangerSign sign = dangerSigns.get(position);
        holder.imageView.setImageResource(sign.getImageResId());
        holder.textView.setText(sign.getText());
    }

    @Override
    public int getItemCount() {
        return dangerSigns.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textView;
        CardView cardView; // Fix: Added this declaration

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.cardView); // Fix: Ensure this ID exists in item_danger_sign.xml
            imageView = itemView.findViewById(R.id.imageView);
            textView = itemView.findViewById(R.id.textView);
        }
    }
}
