public class VideoModel {
    private String videoName, videoUrl, thumbnailUrl;

    public VideoModel(String videoName, String videoUrl, String thumbnailUrl) {
        this.videoName = videoName;
        this.videoUrl = videoUrl;
        this.thumbnailUrl = thumbnailUrl;
    }

    public String getVideoName() { return videoName; }
    public String getVideoUrl() { return videoUrl; }
    public String getThumbnailUrl() { return thumbnailUrl; }
}
