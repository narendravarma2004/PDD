package com.example.bumpstrong;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DTaskActivity extends AppCompatActivity {

    private RecyclerView rvDoctorTasks;
    private SharedPreferences prefs, taskPrefs;
    private String doctorId;

    private static final String PREFS_NAME = "LoginPrefs";
    private static final String DOCTOR_ID_KEY = "doctor_id";
    private static final String TASK_PREFS = "DoctorTaskPrefs";
    private List<String> tasks;
    private DoctorTaskAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_task);

        rvDoctorTasks = findViewById(R.id.rvDoctorTasks);
        if (rvDoctorTasks == null) {
            Toast.makeText(this, "RecyclerView not found! Check your layout file.", Toast.LENGTH_LONG).show();
            return;
        }

        rvDoctorTasks.setLayoutManager(new LinearLayoutManager(this));

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        taskPrefs = getSharedPreferences(TASK_PREFS, MODE_PRIVATE);

        // Get doctor ID passed via intent or from SharedPreferences
        doctorId = getIntent().getStringExtra("DOCTOR_ID");
        if (doctorId == null || doctorId.trim().isEmpty()) {
            doctorId = prefs.getString(DOCTOR_ID_KEY, "");
        }

        if (doctorId == null || doctorId.trim().isEmpty()) {
            Toast.makeText(this, "No Doctor ID found", Toast.LENGTH_SHORT).show();
            finish(); // close activity if no ID
            return;
        }

        loadTasks();
    }

    private void loadTasks() {
        String today = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

        tasks = getTasksForToday();

        List<String> uncompletedTasks = new ArrayList<>();
        for (String task : tasks) {
            String key = today + "_" + doctorId + "_" + task.hashCode();
            if (!taskPrefs.getBoolean(key, false)) {
                uncompletedTasks.add(task);
            }
        }

        adapter = new DoctorTaskAdapter(uncompletedTasks, task -> {
            String key = today + "_" + doctorId + "_" + task.hashCode();
            taskPrefs.edit().putBoolean(key, true).apply();
            loadTasks(); // refresh list after marking done
        });

        rvDoctorTasks.setAdapter(adapter);
    }

    private List<String> getTasksForToday() {
        List<String> list = new ArrayList<>();
        list.add("Review patient charts");
        list.add("Respond to lab reports");
        list.add("Conduct virtual consultations");
        list.add("Attend department meeting");
        return list;
    }
}
