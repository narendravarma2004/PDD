package com.example.bumpstrong;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class KickCountActivity extends AppCompatActivity {

    private int kickCount = 0;
    private TextView kickCountText;
    private Button incrementButton, decrementButton, resetButton;
    private static final String UPDATE_URL = "http://192.168.85.64/bumpstrong/kickcount.php";
    private static final String TAG = "KickCountActivity";
    private String patientId;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kickcount);

        kickCountText = findViewById(R.id.kickCountText);
        incrementButton = findViewById(R.id.incrementButton);
        decrementButton = findViewById(R.id.decrementButton);
        resetButton = findViewById(R.id.resetButton);

        // Retrieve patient_id from SharedPreferences
        sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        patientId = sharedPreferences.getString("patient_id", null);

        if (patientId != null) {
            fetchKickCount(patientId);
        } else {
            Toast.makeText(this, "Patient ID not found", Toast.LENGTH_LONG).show();
        }

        incrementButton.setOnClickListener(v -> updateKickCount("increment"));
        decrementButton.setOnClickListener(v -> updateKickCount("decrement"));
        resetButton.setOnClickListener(v -> updateKickCount("reset"));
    }

    private void fetchKickCount(String patientId) {
        new Thread(() -> {
            try {
                String encodedPatientId = URLEncoder.encode(patientId, "UTF-8");
                URL url = new URL(UPDATE_URL + "?patient_id=" + encodedPatientId);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                int responseCode = conn.getResponseCode();
                if (responseCode != HttpURLConnection.HTTP_OK) {
                    throw new Exception("Server returned response code: " + responseCode);
                }

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                JSONObject jsonResponse = new JSONObject(response.toString());
                int count = jsonResponse.optInt("kick_count", 0);

                runOnUiThread(() -> {
                    kickCount = count;
                    updateKickCountUI();
                });
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(KickCountActivity.this, "Error fetching kick count", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private void updateKickCount(String action) {
        if (patientId == null) {
            Toast.makeText(this, "Patient ID is missing!", Toast.LENGTH_SHORT).show();
            return;
        }

        switch (action) {
            case "increment":
                kickCount++;
                break;
            case "decrement":
                if (kickCount > 0) kickCount--;
                break;
            case "reset":
                kickCount = 0;
                break;
        }

        updateKickCountUI();
        sendKickCountToServer(patientId, kickCount, action); // Send action
    }

    private void sendKickCountToServer(String patientId, int count, String action) {
        new Thread(() -> {
            try {
                URL url = new URL(UPDATE_URL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);

                JSONObject postData = new JSONObject();
                postData.put("patient_id", patientId);
                postData.put("kick_count", count);  // Optional, but can be removed since the action determines the count
                postData.put("action", action); // Add action (increment, decrement, reset)

                OutputStream os = conn.getOutputStream();
                os.write(postData.toString().getBytes("UTF-8"));
                os.flush();
                os.close();

                int responseCode = conn.getResponseCode();
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                Log.d(TAG, "Server Response: " + response.toString());

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    JSONObject jsonResponse = new JSONObject(response.toString());
                    runOnUiThread(() -> {
                        Toast.makeText(KickCountActivity.this, jsonResponse.optString("message"), Toast.LENGTH_SHORT).show();
                    });
                } else {
                    throw new Exception("Server Error: " + responseCode);
                }

            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(KickCountActivity.this, "Error updating kick count", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }



    private void updateKickCountUI() {
        runOnUiThread(() -> kickCountText.setText("Current Kick Count: " + kickCount));
    }
}
