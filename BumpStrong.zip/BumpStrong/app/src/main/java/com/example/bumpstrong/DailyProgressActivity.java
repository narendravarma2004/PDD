package com.example.bumpstrong;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class DailyProgressActivity extends AppCompatActivity {

    private ListView listView;
    private ProgressAdapter progressAdapter;
    private List<ProgressModel> progressList;
    private static final String API_URL = "http://192.168.85.64/bumpstrong/get_progress.php"; // Change this to your actual URL

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dailyprogress); // Ensure this is correct

        // 🔹 Correctly initialize ListView
        listView = findViewById(R.id.listView);
        if (listView == null) {
            Toast.makeText(this, "ListView is NULL!", Toast.LENGTH_LONG).show();
            return;
        }

        progressList = new ArrayList<>();
        progressAdapter = new ProgressAdapter(this, progressList);
        listView.setAdapter(progressAdapter);

        new FetchProgressData().execute(API_URL);
    }

    private class FetchProgressData extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {
            StringBuilder result = new StringBuilder();
            try {
                URL url = new URL(urls[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);
                connection.connect();

                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    InputStream inputStream = connection.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        result.append(line);
                    }
                    reader.close();
                } else {
                    return null;
                }
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
            return result.toString();
        }

        @Override
        protected void onPostExecute(String json) {
            if (json != null) {
                try {
                    JSONArray jsonArray = new JSONArray(json);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);
                        int id = obj.getInt("id");
                        String patientId = obj.getString("patient_id");
                        String taskDate = obj.getString("task_date");
                        int completed = obj.getInt("completed");

                        progressList.add(new ProgressModel(id, patientId, taskDate, completed));
                    }
                    progressAdapter.notifyDataSetChanged();
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(DailyProgressActivity.this, "JSON Parsing Error", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(DailyProgressActivity.this, "Failed to load data", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
