package com.example.bumpstrong;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnDoctor = findViewById(R.id.btnDoctor);
        Button btnPatient = findViewById(R.id.btnPatient);

        btnDoctor.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DoctorLoginActivity.class);
            startActivity(intent);
        });

        btnPatient.setOnClickListener(v -> {
            // Patient login activity if exists
            Intent intent = new Intent(MainActivity.this, PatientLoginActivity.class);
            startActivity(intent);
        });
    }
}
