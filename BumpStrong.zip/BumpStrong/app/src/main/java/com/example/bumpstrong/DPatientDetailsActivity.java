package com.example.bumpstrong;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class DPatientDetailsActivity extends AppCompatActivity {

    private TextView tvPatientId, tvName, tvAge, tvEducation, tvOccupation, tvPhoneNumber,
            tvBloodGroup, tvLmpDate, tvDueDate, tvAbortionHistory, tvRelativeToHusband,
            tvConfirmationOfPregnancy, tvWeight, tvHeight, tvObstetricScore, tvMaritalStatus;
    private static final String TAG = "PatientDetailsActivity";
    private static final String FETCH_URL = "http://192.168.85.64/bumpstrong/fetch_patient_by_name.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d_patient_details);

        // Initialize TextViews
        tvPatientId = findViewById(R.id.tvPatientId);
        tvName = findViewById(R.id.tvName);
        tvAge = findViewById(R.id.tvAge);
        tvEducation = findViewById(R.id.tvEducation);
        tvOccupation = findViewById(R.id.tvOccupation);
        tvPhoneNumber = findViewById(R.id.tvPhoneNumber);
        tvBloodGroup = findViewById(R.id.tvBloodGroup);
        tvLmpDate = findViewById(R.id.tvLmpDate);
        tvDueDate = findViewById(R.id.tvDueDate);
        tvAbortionHistory = findViewById(R.id.tvAbortionHistory);
        tvRelativeToHusband = findViewById(R.id.tvRelativeToHusband);
        tvConfirmationOfPregnancy = findViewById(R.id.tvConfirmationOfPregnancy);
        tvWeight = findViewById(R.id.tvWeight);
        tvHeight = findViewById(R.id.tvHeight);
        tvObstetricScore = findViewById(R.id.tvObstetricScore);
        tvMaritalStatus = findViewById(R.id.tvMaritalStatus);

        // Get patient name from intent
        String patientName = getIntent().getStringExtra("PATIENT_NAME");
        if (patientName != null) {
            Log.d(TAG, "Fetching details for patient: " + patientName);
            fetchPatientDetails(patientName);
        } else {
            Toast.makeText(this, "No patient name provided", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void fetchPatientDetails(String patientName) {
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                String encodedName = URLEncoder.encode(patientName, "UTF-8");
                URL url = new URL(FETCH_URL + "?name=" + encodedName);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                int responseCode = conn.getResponseCode();
                Log.d(TAG, "Server response code: " + responseCode);

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder result = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        result.append(line);
                    }
                    reader.close();

                    String rawResponse = result.toString();
                    Log.d(TAG, "Raw response from server: " + rawResponse);

                    JSONObject jsonObject = new JSONObject(rawResponse);
                    if (jsonObject.has("error")) {
                        String errorMsg = jsonObject.getString("error");
                        runOnUiThread(() -> Toast.makeText(this, "Server error: " + errorMsg, Toast.LENGTH_LONG).show());
                        return;
                    }

                    runOnUiThread(() -> updateUI(jsonObject));
                } else {
                    String errorMsg = "Server error: " + responseCode;
                    runOnUiThread(() -> Toast.makeText(this, errorMsg, Toast.LENGTH_LONG).show());
                    Log.e(TAG, errorMsg);
                }
            } catch (Exception e) {
                Log.e(TAG, "Error fetching patient details: " + e.getMessage(), e);
                runOnUiThread(() -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show());
            } finally {
                if (conn != null) {
                    conn.disconnect();
                }
            }
        }).start();
    }

    private void updateUI(JSONObject jsonObject) {
        try {
            JSONObject patient = jsonObject.getJSONObject("patient");

            tvPatientId.setText("ID: " + patient.optString("patient_id", "N/A"));
            tvName.setText("Name: " + patient.optString("firstName", "N/A") + " " + patient.optString("lastName", "N/A"));
            tvAge.setText("Age: " + patient.optInt("age", 0) + " years");
            tvEducation.setText("Education: " + patient.optString("education", "N/A"));
            tvOccupation.setText("Occupation: " + patient.optString("occupation", "N/A"));
            tvPhoneNumber.setText("Phone: " + patient.optString("phoneNumber", "N/A"));
            tvBloodGroup.setText("Blood Group: " + patient.optString("bloodGroup", "N/A"));
            tvLmpDate.setText("LMP Date: " + patient.optString("lmpDate", "N/A"));
            tvDueDate.setText("Due Date: " + patient.optString("dueDate", "N/A"));
            tvAbortionHistory.setText("Abortion History: " + patient.optString("abortionHistory", "N/A"));
            tvRelativeToHusband.setText("Relative to Husband: " + patient.optString("relativeToHusband", "N/A"));
            tvConfirmationOfPregnancy.setText("Pregnancy Confirmation: " + patient.optString("confirmationOfPregnancy", "N/A"));
            tvWeight.setText("Weight: " + String.format("%.1f kg", patient.optDouble("weight", 0.0)));
            tvHeight.setText("Height: " + String.format("%.1f cm", patient.optDouble("Height", 0.0)));
            tvObstetricScore.setText("Obstetric Score: " + patient.optInt("obstetricScore", 0));
            tvMaritalStatus.setText("Marital Status: " + patient.optString("maritalStatus", "N/A"));

        } catch (Exception e) {
            Log.e(TAG, "Error parsing data: " + e.getMessage(), e);
            Toast.makeText(this, "Error parsing data: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}